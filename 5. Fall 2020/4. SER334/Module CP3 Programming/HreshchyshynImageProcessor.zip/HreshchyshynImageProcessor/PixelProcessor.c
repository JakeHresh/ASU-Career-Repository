#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "PixelProcessor.h"

/**
 * Shift color of Pixel array. The dimension of the array is width * height. The shift value of RGB is
 * rShift, gShift，bShift. Useful for color shift.
 *
 * @param  pArr: Pixel array of the image that this header is for
 * @param  width: Width of the image that this header is for
 * @param  height: Height of the image that this header is for
 * @param  rShift: the shift value of color r shift
 * @param  gShift: the shift value of color g shift
 * @param  bShift: the shift value of color b shift
 */
void colorShiftPixels(struct Pixel** pArr, int width, int height, int rShift, int gShift, int bShift) // work in progress, but it does shift the pixels.
{
    printf("First red byte: %d\n", pArr[0][0].red_byte);
    printf("First red byte + 56: %d\n", pArr[0][0].red_byte + 56);
    for(int i = 0; i < height; i++) // visit each element of pixel array and initialize r g b values of pixels by using fread. LAST BYTE IS READ FIRST in B G R order
    {
        for(int j = 0; j < width; j++)
        {
            pArr[j][i].red_byte += rShift;
            if(pArr[j][i].red_byte < 0)
            {
                pArr[j][i].red_byte = 0;
            }
            if(pArr[j][i].red_byte > 255)
            {
                pArr[j][i].red_byte = 255;
            }

            pArr[j][i].green_byte += gShift;
            if(pArr[j][i].green_byte < 0)
            {
                pArr[j][i].green_byte = 0;
            }
            if(pArr[j][i].green_byte > 255)
            {
                pArr[j][i].green_byte = 255;
            }

            pArr[j][i].blue_byte += bShift;
            if(pArr[j][i].blue_byte < 0)
            {
                pArr[j][i].blue_byte = 0;
            }
            if(pArr[j][i].blue_byte > 255)
            {
                pArr[j][i].blue_byte = 255;
            }
        }
        //fseek(file, pad_size, SEEK_CUR);// skips padding.
    }
}