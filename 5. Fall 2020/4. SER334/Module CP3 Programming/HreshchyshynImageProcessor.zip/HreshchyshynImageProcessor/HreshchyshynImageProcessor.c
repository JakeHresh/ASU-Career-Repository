/*
 * The program is capable of reading existing bmp and ppm files, converting between bmp and ppm (and vice versa), and
 * applying a color shift that shifts the rgb values of an image by a specified amount. These specifcations and file
 * selections are made through the command line.
 *
 * Completion Time: 35 hours
 *
 * Authors: Jacob Hreshchyshyn, Professor Acuna
 *
 * Version 1.0
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "PpmProcessor.h"
#include "PixelProcessor.h"
#include "BmpProcessor.h"
#include <ctype.h>
// argc number of arguments
// argv[0] is the program name. That can be skipped.
// check if it starts with a dash.
// pass function the argv
// file name would be argv[1]
// use strcmp to compare arguments and check for -r, -o, etc. returns 0 if they're the same
// try reading the ppm file in as binary
// use strlen to get length of string
int main(int argc, char* argv[]) {
    //create array of pixel structs that will store pixel info of a file
    int o = 0;
    int r = 0;
    int g = 0;
    int b = 0;
    int rNum = 0;
    int bNum = 0;
    int gNum = 0;
    char* rNumStr;
    char* bNumStr;
    char* gNumStr;
    int inputBMP = 0;
    int inputPPM = 0;
    int outputBMP = 0;
    int outputPPM = 0;
    char bmpCompare[5] = ".bmp";
    char ppmCompare[5] = ".ppm";
    char oCompare[3] = "-o";
    char rCompare[3] = "-r";
    char gCompare[3] = "-g";
    char bCompare[3] = "-b";
    char* outputFile;
    // use strtok to get file extension
    //char testExtension[5];

    //Following section works. Correctly accesses file extension and stores it in extension check. There will be a check to make sure it matches the accepted formats.
    int i = 0;
    char extensionCheck[5];
    while(argv[1][i] != '\0')
    {
        i++;//results in index where i = null character
    }
    int tracker = 0;
    for(int j = i; j > i - 5; j--)
    {
        extensionCheck[4 - tracker] = argv[1][j];
        tracker++;
    }
    printf("%s\n", extensionCheck);
    if(strcmp(extensionCheck, bmpCompare) == 0)
    {
        inputBMP = 1;
    }
    else if(strcmp(extensionCheck, ppmCompare) == 0)
    {
        inputPPM = 1;
    }
    else
    {
        printf("Error. Unrecognized file type.\n");
        exit(1);
    }
    printf("Input BMP: %d\n", inputBMP);
    printf("Input PPM: %d\n", inputPPM);
    // check for other things that need to be done.
    for(int i = 2; i < argc; i++) // appears to process
    {
        int skipped = 0;
        if(strcmp(argv[i], oCompare) == 0 && o != 1)
        {
            if(skipped == 0)
            {
                outputFile = argv[i + 1]; // get file name, which is after the -o command
                o = 1;
                i++; // because the next argument is saved, it should be skipped so as not to be read again
                skipped = 1;
            }
        }
        else if(strcmp(argv[i], oCompare) == 0 && o == 1)
        {
            if(skipped == 0)
            {
                printf("Error. Duplicate -o parameter.\n");
                exit(1);
            }
        }
        if(strcmp(argv[i], rCompare) == 0 && r != 1)
        {
            if(skipped == 0)
            {
                rNumStr = argv[i + 1]; // get r number string
                r = 1;
                i++; // red number value should be skipped
                skipped = 1;
            }
        }
        else if(strcmp(argv[i], rCompare) == 0 && r == 1)
        {
            if(skipped == 0)
            {
                printf("Error. Duplicate -r parameter.\n");
                exit(1);
            }
        }
        if(strcmp(argv[i], gCompare) == 0 && g != 1)
        {
            if(skipped == 0)
            {
                gNumStr = argv[i + 1]; // get r number string
                g = 1;
                i++; // green color value should be skipped
                skipped = 1;
            }
        }
        else if(strcmp(argv[i], gCompare) == 0 && g == 1)
        {
            if(skipped == 0)
            {
                printf("Error. Duplicate -g parameter.\n");
                exit(1);
            }
        }
        if(strcmp(argv[i], bCompare) == 0 && b != 1)
        {
            if(skipped == 0)
            {
                bNumStr = argv[i + 1]; // get r number string
                b = 1;
                i++; // blue color value should be skipped
                skipped = 1;
            }
        }
        else if(strcmp(argv[i], bCompare) == 0 && b == 1)
        {
            if(skipped == 0)
            {
                printf("Error. Duplicate -b parameter.\n");
                exit(1);
            }
        }
        //if(o == 1) // this condition will check for any extra strings that don't belong or if the output file is in the wrong place
        //{
            if(strcmp(argv[i], oCompare) != 0 && strcmp(argv[i], rCompare) != 0 && strcmp(argv[i], gCompare) != 0 && strcmp(argv[i], bCompare) != 0)// && strcmp(argv[i], outputFile) != 0)
            {
                if(skipped == 0)
                {
                    printf("Error. Invalid string or string placement.\n");
                    exit(1);
                }
            }
        //}
    }
    // if inputBMP = 1, open file and read BMP using argv[1] to access file name
    // otherwise, open file and read PPM using argv[1] to access file name
    printf("%d \n", argc);
    // check if you're reading from bmp or ppm. If bmp, read and write with binary only. If ppm, read header with ascii and pixels with binary. Do the same for writing
    FILE* file_input;
    if(inputBMP == 1)
    {
        file_input = fopen(argv[1], "rb"); // read argv[1], which is the name of the file to open.
        if(file_input == NULL)
        {
            printf("Error. File not found.\n");
            exit(1);
        }
        struct BMP_Header* header = (struct BMP_Header*)malloc(sizeof(struct BMP_Header));
        struct DIB_Header* header_dib = (struct DIB_Header*)malloc(sizeof(struct BMP_Header));

        readBMPHeader(file_input, header);
        readDIBHeader(file_input, header_dib);

        struct Pixel** pArr; // pixel struct for storing pixels. Need to allocate size of struct to store a collection of pixels.
        // assuming the pixel array is being allocated memory based on a BMP file
        pArr = (struct Pixel**)malloc(sizeof(struct Pixel*) * header_dib->image_width);
        for(int p = 0; p < header_dib->image_width; p++)
        {
            pArr[p] = (struct Pixel*)malloc(sizeof(struct Pixel) * header_dib->image_height);
        }

        readPixelsBMP(file_input, pArr, header_dib->image_width, header_dib->image_height);

        if(r == 1)
        {
            int i = 0;
            if(rNumStr[0] == '-')
            {
                i++;
            }
            while(rNumStr[i] != '\0')
            {
                if(isdigit(rNumStr[i]) == 0)
                {
                    printf("Error. Red value not a number.\n");
                    exit(1);
                }
                i++;
            }
            rNum = atoi(rNumStr);
        }
        if(g == 1)
        {
            int i = 0;
            if(gNumStr[0] == '-')
            {
                i++;
            }
            while(gNumStr[i] != '\0')
            {
                if(isdigit(gNumStr[i]) == 0)
                {
                    printf("Error. Green value not a number.\n");
                    exit(1);
                }
                i++;
            }
            gNum = atoi(gNumStr);
        }
        if(b == 1)
        {
            int i = 0;
            if(bNumStr[0] == '-')
            {
                i++;
            }
            while(bNumStr[i] != '\0')
            {
                if(isdigit(bNumStr[i]) == 0)
                {
                    printf("Error. Blue value not a number.\n");
                    exit(1);
                }
                i++;
            }
            bNum = atoi(bNumStr);
        }
        // REVIEW COLOR SHIFT AND SEE WHY IT'S NOT WORKING
        colorShiftPixels(pArr, header_dib->image_width, header_dib->image_height, rNum, gNum, bNum); // see why this isn't working
        if(o == 1)
        {
            int k = 0;
            char extensionCheckOut[5];
            while(outputFile[k] != '\0')
            {
                k++;//results in index where k = null character
            }
            int tracker2 = 0;
            for(int j = k; j > k - 5; j--)
            {
                extensionCheckOut[4 - tracker2] = outputFile[j];
                tracker2++;
            }
            printf("%s\n", extensionCheckOut);
            if(strcmp(extensionCheckOut, bmpCompare) == 0)
            {
                outputBMP = 1;
            }
            else if(strcmp(extensionCheckOut, ppmCompare) == 0)
            {
                outputPPM = 1;
            }
            else
            {
                printf("Error. Unrecognized output file type.\n");
                exit(1);
            }
            if(outputBMP == 1)
            {
                FILE* fOut = fopen(outputFile, "wb");
                writeBMPHeader(fOut, header);
                writeDIBHeader(fOut, header_dib);
                writePixelsBMP(fOut, pArr, header_dib->image_width, header_dib->image_height);
            }
            else if(outputPPM == 1)
            {
                FILE* fOut = fopen(outputFile, "w");// should be incorrect at first when reading file. Change from r to rb when writing pixel info
                struct PPM_Header* ppm_header = (struct PPM_Header*)malloc(sizeof(struct PPM_Header));
                struct Pixel** pArr2; // pixel struct for storing pixels. Need to allocate size of struct to store a collection of pixels.
                // assuming the pixel array is being allocated memory based on a BMP file
                pArr2 = (struct Pixel**)malloc(sizeof(struct Pixel*) * header_dib->image_width);
                for(int p = 0; p < header_dib->image_width; p++)
                {
                    pArr2[p] = (struct Pixel*)malloc(sizeof(struct Pixel) * header_dib->image_height);
                }
                makePPMHeader(ppm_header, header_dib->image_width, header_dib->image_height);
                // LOOP TRANSFERS PIXEL DATA FROM BMP TO PPM Pixel array
                for(int i = 0; i < header_dib->image_height; i++)
                {
                    for(int j = 0; j < header_dib->image_width; j++)
                    {
                        pArr2[j][i].red_byte = pArr[j][(header_dib->image_height-1) - i].red_byte;
                        pArr2[j][i].green_byte = pArr[j][(header_dib->image_height-1) - i].green_byte;
                        pArr2[j][i].blue_byte = pArr[j][(header_dib->image_height-1) - i].blue_byte;
                    }
                }
                writePPMHeader(fOut, ppm_header);
                writePixelsPPM(fOut, pArr2, header_dib->image_width, header_dib->image_height);
            }
        }
        else
        {
            FILE* file_output = fopen(argv[1], "wb");
            writeBMPHeader(file_output, header);
            writeDIBHeader(file_output, header_dib);
            writePixelsBMP(file_output, pArr, header_dib->image_width, header_dib->image_height);
        }
    }
    else if(inputPPM == 1)
    {
        file_input = fopen(argv[1], "r");
        if(file_input == NULL)
        {
            printf("Error. File not found.\n");
            exit(1);
        }
        struct PPM_Header* ppm_header = (struct PPM_Header*)malloc(sizeof(struct PPM_Header));

        readPPMHeader(file_input, ppm_header);

        struct Pixel** pArr; // pixel struct for storing pixels. Need to allocate size of struct to store a collection of pixels.
        // assuming the pixel array is being allocated memory based on a BMP file
        pArr = (struct Pixel**)malloc(sizeof(struct Pixel*) * ppm_header->width);
        for(int p = 0; p < ppm_header->width; p++)
        {
            pArr[p] = (struct Pixel*)malloc(sizeof(struct Pixel) * ppm_header->height);
        }

        readPixelsPPM(file_input, pArr, ppm_header->width, ppm_header->height); // may be something going wrong in reading pixels in using r.

        if(r == 1)
        {
            int i = 0;
            if(rNumStr[0] == '-')
            {
                i++;
            }
            while(rNumStr[i] != '\0')
            {
                if(isdigit(rNumStr[i]) == 0)
                {
                    printf("Error. Red value not a number.\n");
                    exit(1);
                }
                i++;
            }
            rNum = atoi(rNumStr);
        }
        if(g == 1)
        {
            int i = 0;
            if(gNumStr[0] == '-')
            {
                i++;
            }
            while(gNumStr[i] != '\0')
            {
                if(isdigit(gNumStr[i]) == 0)
                {
                    printf("Error. Green value not a number.\n");
                    exit(1);
                }
                i++;
            }
            gNum = atoi(gNumStr);
        }
        if(b == 1)
        {
            int i = 0;
            if(bNumStr[0] == '-')
            {
                i++;
            }
            while(bNumStr[i] != '\0')
            {
                if(isdigit(bNumStr[i]) == 0)
                {
                    printf("Error. Blue value not a number.\n");
                    exit(1);
                }
                i++;
            }
            bNum = atoi(bNumStr);
        }
        // REVIEW COLOR SHIFT AND SEE WHY IT'S NOT WORKING
        colorShiftPixels(pArr, ppm_header->width, ppm_header->height, rNum, gNum, bNum); // see why this isn't working
        if(o == 1)
        {
            int k = 0;
            char extensionCheckOut[5];
            while(outputFile[k] != '\0')
            {
                k++;//results in index where k = null character
            }
            int tracker2 = 0;
            for(int j = k; j > k - 5; j--)
            {
                extensionCheckOut[4 - tracker2] = outputFile[j];
                tracker2++;
            }
            printf("%s\n", extensionCheckOut);
            if(strcmp(extensionCheckOut, bmpCompare) == 0)
            {
                outputBMP = 1;
            }
            else if(strcmp(extensionCheckOut, ppmCompare) == 0)
            {
                outputPPM = 1;
            }
            else
            {
                printf("Error. Unrecognized output file type.\n");
                exit(1);
            }
            if(outputPPM == 1)
            {
                FILE* fOut = fopen(outputFile, "w");
                writePPMHeader(fOut, ppm_header);
                writePixelsPPM(fOut, pArr, ppm_header->width, ppm_header->height);
            }
            else if(outputBMP == 1)
            {
                printf("output is bmp\n");
                FILE* fOut = fopen(outputFile, "wb");// should be incorrect at first when reading file. Change from r to rb when writing pixel info
                struct BMP_Header* bmp_header = (struct BMP_Header*)malloc(sizeof(struct BMP_Header));
                struct DIB_Header* bmp_header_dib = (struct DIB_Header*)malloc(sizeof(struct DIB_Header));
                struct Pixel** pArr2; // pixel struct for storing pixels. Need to allocate size of struct to store a collection of pixels.
                // assuming the pixel array is being allocated memory based on a BMP file
                pArr2 = (struct Pixel**)malloc(sizeof(struct Pixel*) * ppm_header->width);
                for(int p = 0; p < ppm_header->width; p++)
                {
                    pArr2[p] = (struct Pixel*)malloc(sizeof(struct Pixel) * ppm_header->height);
                }
                makeBMPHeader(bmp_header, ppm_header->width, ppm_header->height);
                makeDIBHeader(bmp_header_dib, ppm_header->width, ppm_header->height);
                // LOOP TRANSFERS PIXEL DATA FROM BMP TO PPM Pixel array
                for(int i = 0; i < ppm_header->height; i++)
                {
                    for(int j = 0; j < ppm_header->width; j++) // no changes should be made since it's just swapping the bottom to top positions of pixel values. Be sure to check
                    {
                        pArr2[j][i].red_byte = pArr[j][(ppm_header->height-1) - i].red_byte;
                        pArr2[j][i].green_byte = pArr[j][(ppm_header->height-1) - i].green_byte;
                        pArr2[j][i].blue_byte = pArr[j][(ppm_header->height-1) - i].blue_byte;
                    }
                }
                writeBMPHeader(fOut, bmp_header);
                writeDIBHeader(fOut, bmp_header_dib);
                writePixelsBMP(fOut, pArr2, ppm_header->width, ppm_header->height);
            }
        }
        else // modify so that it writes new ppm file as normal
        {
            FILE* file_output = fopen(argv[1], "w");
            writePPMHeader(file_output, ppm_header);
            writePixelsBMP(file_output, pArr, ppm_header->width, ppm_header->height);
        }
    }

    //*****************TEST FOR READING PPM HEADER
   /* FILE* file_input = fopen("/home/jacob/Desktop/nehoymenoy.ppm", "r");
    struct PPM_Header* ppmHeader = (struct PPM_Header*)malloc(sizeof(struct PPM_Header));
    struct Pixel** pArr = (struct Pixel**)malloc(sizeof(struct Pixel));

    readPPMHeader(file_input, ppmHeader);
    printf("magic number: %c%c%c\n", ppmHeader->magic_number[0], ppmHeader->magic_number[1], ppmHeader->magic_number[2]);
    printf("width: %d\n", ppmHeader->width);
    printf("height: %d\n", ppmHeader->height);
    printf("max color value: %d\n", ppmHeader->max_color_value);

    pArr = (struct Pixel**)malloc(sizeof(struct Pixel*) * ppmHeader->width);
    for(int p = 0; p < ppmHeader->width; p++)
    {
        pArr[p] = (struct Pixel*)malloc(sizeof(struct Pixel) * ppmHeader->height);
    }

    readPixelsPPM(file_input, pArr, ppmHeader->width, ppmHeader->height);

    fclose(file_input);

    FILE* file_output = fopen("/home/jacob/Desktop/nehoymenoy2.ppm", "w");
    writePPMHeader(file_output, ppmHeader);
    writePixelsPPM(file_output, pArr, ppmHeader->width, ppmHeader->height);
    fclose(file_output);

    FILE* file = fopen("/home/jacob/Desktop/nehoymenoy2.ppm", "r");

    readPPMHeader(file, ppmHeader);
    printf("magic number: %c%c%c\n", ppmHeader->magic_number[0], ppmHeader->magic_number[1], ppmHeader->magic_number[2]);
    printf("width: %d\n", ppmHeader->width);
    printf("height: %d\n", ppmHeader->height);
    printf("max color value: %d\n", ppmHeader->max_color_value);

    for(int i = 0; i < ppmHeader->height; i++)
    {
        for(int j = 0; j < ppmHeader->width; j++)
        {
            printf("%p", pArr[j][i].red_byte);
            printf("%p", pArr[j][i].green_byte);
            printf("%p", pArr[j][i].blue_byte);
        }
        printf("\n");
    }

    fclose(file);
*/
    //*****************TEST FOR WRITING PPM HEADER
    //*****************TEST FOR READING HEADER
   /* printf("Hello, World!\n");
    FILE* file_input = fopen("/home/jacob/Desktop/ttt.bmp", "rb");

    struct BMP_Header* header = (struct BMP_Header*)malloc(sizeof(struct BMP_Header));
    struct DIB_Header* header_dib = (struct DIB_Header*)malloc(sizeof(struct BMP_Header));

    readBMPHeader(file_input, header);
    readDIBHeader(file_input, header_dib);

    printf("signature: %c%c\n", header->signature[0], header->signature[1]);
    printf("file size: %d\n", header->size);
    printf("reserved1: %d\n", header->reserved1);
    printf("reserved2: %d\n", header->reserved2);
    printf("offset: %d\n", header->offset_pixel_array);

    printf("dib header size: %d\n", header_dib->dib_header_size);
    printf("image width: %d\n", header_dib->image_width);
    printf("image height: %d\n", header_dib->image_height);
    printf("planes: %d\n", header_dib->planes);
    printf("bits per pixel: %d\n", header_dib->bits_per_pixel);
    printf("compression: %d\n", header_dib->compression);
    printf("image size: %d\n", header_dib->image_size);
    printf("x pixels per meter: %d\n", header_dib->x_pixels_per_meter);
    printf("y pixels per meter: %d\n", header_dib->y_pixels_per_meter);
    printf("colors in color table: %d\n", header_dib->colors_in_color_table);
    printf("important color count: %d\n", header_dib->important_color_count);
    //TEST PIXEL ARRAY THAT WILL STORE INFO OF BMP FILE
    struct Pixel** pArr; // pixel struct for storing pixels. Need to allocate size of struct to store a collection of pixels.
    // assuming the pixel array is being allocated memory based on a BMP file
    pArr = (struct Pixel**)malloc(sizeof(struct Pixel*) * header_dib->image_width);
    for(int p = 0; p < header_dib->image_width; p++)
    {
        pArr[p] = (struct Pixel*)malloc(sizeof(struct Pixel) * header_dib->image_height);
    }
    // with this, try reading pixel info into array,
    // then writing array pixel info back into new bmp file.

    readPixelsBMP(file_input, pArr, header_dib->image_width, header_dib->image_height); // this must be read after reading dib header
    for(int i = 0; i < header_dib->image_height; i++)
    {
        for(int j = 0; j < header_dib->image_width; j++)
        {
            printf("%p", pArr[j][i].blue_byte);
            printf("%p", pArr[j][i].green_byte);
            printf("%p", pArr[j][i].red_byte);
        }
        printf("\n");
    }
*/
    //*****************TEST FOR READING HEADER
    //fclose(file_input);
    //*****************TEST FOR WRITING HEADER
    /*FILE* file_output = fopen("/home/jacob/Desktop/ttt2.bmp", "wb");

    printf("\n\nsignature: %c%c\n", header->signature[0], header->signature[1]);
    printf("file size: %d\n", header->size);


    writeBMPHeader(file_output, header);
    writeDIBHeader(file_output, header_dib);
    //APPLY COLOR SHIFT
    colorShiftPixels(pArr, header_dib->image_width, header_dib->image_height, -255, -255, -255);
    writePixelsBMP(file_output, pArr, header_dib->image_width, header_dib->image_height);
    fclose(file_output);

    FILE* file = fopen("/home/jacob/Desktop/ttt2.bmp", "rb");
    struct BMP_Header* header2 = (struct BMP_Header*)malloc(sizeof(struct BMP_Header));
    struct DIB_Header* header_dib2 = (struct DIB_Header*)malloc(sizeof(struct BMP_Header));

    readBMPHeader(file, header2);
    readDIBHeader(file, header_dib2);

    printf("\n\nReading created file.\n\n");

    printf("signature: %c%c\n", header2->signature[0], header2->signature[1]);
    printf("file size: %d\n", header2->size);
    printf("reserved1: %d\n", header2->reserved1);
    printf("reserved2: %d\n", header2->reserved2);
    printf("offset: %d\n", header2->offset_pixel_array);

    printf("dib header size: %d\n", header_dib2->dib_header_size);
    printf("image width: %d\n", header_dib2->image_width);
    printf("image height: %d\n", header_dib2->image_height);
    printf("planes: %d\n", header_dib2->planes);
    printf("bits per pixel: %d\n", header_dib2->bits_per_pixel);
    printf("compression: %d\n", header_dib2->compression);
    printf("image size: %d\n", header_dib2->image_size);
    printf("x pixels per meter: %d\n", header_dib2->x_pixels_per_meter);
    printf("y pixels per meter: %d\n", header_dib2->y_pixels_per_meter);
    printf("colors in color table: %d\n", header_dib2->colors_in_color_table);
    printf("important color count: %d\n", header_dib2->important_color_count);

    struct Pixel** pArr2; // pixel struct for storing pixels. Need to allocate size of struct to store a collection of pixels.
    // assuming the pixel array is being allocated memory based on a BMP file
    pArr2 = (struct Pixel**)malloc(sizeof(struct Pixel*) * header_dib2->image_width);
    for(int p = 0; p < header_dib2->image_width; p++)
    {
        pArr2[p] = (struct Pixel*)malloc(sizeof(struct Pixel) * header_dib2->image_height);
    }
    // with this, try reading pixel info into array,
    // then writing array pixel info back into new bmp file.

    readPixelsBMP(file, pArr2, header_dib2->image_width, header_dib2->image_height); // this must be read after reading dib header
    for(int i = 0; i < header_dib2->image_height; i++)
    {
        for(int j = 0; j < header_dib2->image_width; j++)
        {
            printf("%p", pArr2[j][i].blue_byte);
            printf("%p", pArr2[j][i].green_byte);
            printf("%p", pArr2[j][i].red_byte);
        }
        printf("\n");
    }
*/
    //*****************TEST FOR WRITING HEADER

    //ACTUAL WORK OF PROGRAM STARTS HERE


    //name of file to open, name of file to open, -n to create a new file, -r for red shift
    // -g for green shift, -b for blue shift, name of to create
    // input file name should be first argument
    // output file name is an option, specified by -o
    // check that file exists and that files are the correct type
    // check format at end of file name string for validation
    // -r, -g, -b options need to be validated as integers
    // -o for output file name (ppm-ppm, bmp-bmp)
    // -n for new converted file (ppm-bmp, bmp-ppm)
    // use optarg to contain the names of files
    return 0;
}
