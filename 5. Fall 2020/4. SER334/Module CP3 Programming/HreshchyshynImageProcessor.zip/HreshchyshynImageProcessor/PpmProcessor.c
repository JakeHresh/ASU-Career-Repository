#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "PpmProcessor.h"
//#include "PixelProcessor.h"

/**
 * read PPM header of a file. Useful for converting files from BMP to PPM.
 *
 * @param  file: A pointer to the file being read or written
 * @param  header: Pointer to the destination PPM header
 */
void readPPMHeader(FILE* file, struct PPM_Header* header) // works well. Be sure to use atoi when getting the ppm file info
{
    fseek(file, 3, SEEK_SET); // offset by 3 to start reading from width
    /*fgets(header->magic_number, 2048, file);
    fgets(header->width, 2048, file);
    fgets(header->height, 2048, file);
    fgets(header->max_color_value, 2048, file);*/
    header->magic_number[0] = 'P';
    header->magic_number[1] = '6';
    header->magic_number[2] = '\n';

    char widthStr[2048];
    fgets(widthStr, 2048, file);
    header->width = atoi(widthStr);
    printf("%d\n", header->width);

    char heightStr[2048];
    fgets(heightStr, 2048, file);
    header->height = atoi(heightStr);
    printf("%d\n", header->height);

    header->max_color_value = 255;
 }

/**
 * write PPM header of a file. Useful for converting files from BMP to PPM.
 *
 * @param  file: A pointer to the file being read or written
 * @param  header: The header to write to the file

 */
void writePPMHeader(FILE* file, struct PPM_Header* header) // complete. Be sure to use atoi if file info is needed.
{
    fseek(file, 0, SEEK_SET);
    fprintf(file, header->magic_number);
    fprintf(file, "%d\n", header->width);
    fprintf(file, "%d\n", header->height);
    fprintf(file, "%d\n", 255);
    /*char magicNumStr[3] = "P6\n";
    fprintf(file, magicNumStr);
    int width = atoi(header->width);
    char widthStr[10];
    sprintf(widthStr, "%d\n", width);
    printf("width: %d\n", width);
    for(int i = 0; i < 10; i++)
    {
        printf("%c", widthStr[i]);
    }
    printf("That was the widthStr\n");
    printf("width: %d", atoi(widthStr));
    fprintf(file, widthStr);
    int height = atoi(header->height);
    char heightStr[10];
    sprintf(heightStr, "%d\n", height);
    fprintf(file, heightStr);
    char maxColorValStr[4] = {'2','5','5','\n'};
    fprintf(file, maxColorValStr);*/
}

/**
 * make PPM header based on width and height. Useful for converting files from BMP to PPM.
 *
 * @param  header: Pointer to the destination PPM header
 * @param  width: Width of the image that this header is for
 * @param  height: Height of the image that this header is for
 */
void makePPMHeader(struct PPM_Header* header, int width, int height) // complete for now. check back later
{
    header->magic_number[0] = 'P';
    header->magic_number[1] = '6';
    header->magic_number[2] = '\n';
    header->width = width;
    header->height = height;
    header->max_color_value = 255;
    /*header->magic_number[0] = 'P';
    header->magic_number[1] = '6';
    char widthStr[10];
    sprintf(widthStr, "%d\n", width);
    strcpy(header->width, widthStr);
    char heightStr[10];
    sprintf(heightStr, "%d\n", height);
    strcpy(header->height, heightStr);
    header->max_color_value[0] = '2';
    header->max_color_value[1] = '5';
    header->max_color_value[2] = '5';
    header->max_color_value[3] = '2';
    header->max_color_value[4] = '\n';*/
}

/**
 * read Pixels from PPM file based on width and height.
 *
 * @param  file: A pointer to the file being read
 * @param  pArr: Pixel array to store the pixels being read
 * @param  width: Width of the pixel array of this image
 * @param  height: Height of the pixel array of this image
 */
 // check to fix it

void readPixelsPPM(FILE* file, struct Pixel** pArr, int width, int height) // appears to be working. Will test after writing
{
    for(int i = 0; i < height; i++) // visit each element of pixel array and initialize r g b values of pixels by using fread. LAST BYTE IS READ FIRST in B G R order
    {
        for(int j = 0; j < width; j++)
        {
            fread(&pArr[j][i].blue_byte, sizeof(char), 1, file);//[j][i] so that all the information in row is stored
            fread(&pArr[j][i].red_byte, sizeof(char), 1, file);
            fread(&pArr[j][i].green_byte, sizeof(char), 1, file);
        }
        //fseek(file, pad_size, SEEK_CUR);// skips padding.
    }
    printf("NOW READING PIXEL ARRAY\n");
    printf("Red byte: %c\n", pArr[0][0].red_byte);
    printf("Green byte: %c\n", pArr[0][0].green_byte);
    printf("Blue byte: %c\n", pArr[0][0].blue_byte);
    // the first max value for nehoymenoy is 255
}

/**
 * write Pixels from PPM file based on width and height.
 *
 * @param  file: A pointer to the file being read or written
 * @param  pArr: Pixel array of the image to write to the file
 * @param  width: Width of the pixel array of this image
 * @param  height: Height of the pixel array of this image
 */
 //check to fix it

void writePixelsPPM(FILE* file, struct Pixel** pArr, int width, int height) // for some reason, it's not reading writing the info to the ppm file properly. Look into it after converting.
{
    //int row_size = width * 3; // 3 bytes per pixel in row
    //int pad_size = 0;
    /*while(row_size%4 != 0)
    {
        row_size++;
        pad_size++;
    }*/
    //results in variable containing size of row in bytes with padding. pad_size also tracks the number of padding bytes.
    for(int i = 0; i < height; i++) // visit each element of pixel array and initialize r g b values of pixels by using fread. LAST BYTE IS READ FIRST in B G R order
    {
        for(int j = 0; j < width; j++)
        {
            fwrite(&pArr[j][i].red_byte, sizeof(char), 1, file);//[j][i] so that all the information in row is stored
            fwrite(&pArr[j][i].green_byte, sizeof(char), 1, file);
            fwrite(&pArr[j][i].blue_byte, sizeof(char), 1, file);
        }
        //fseek(file, pad_size, SEEK_CUR);// skips padding.
    }
    printf("NOW WRITING PIXEL ARRAY\n");
    printf("Red byte: %d\n", pArr[0][0].red_byte);
    printf("Green byte: %d\n", pArr[0][0].green_byte);
    printf("Blue byte: %d\n", pArr[0][0].blue_byte);
}
