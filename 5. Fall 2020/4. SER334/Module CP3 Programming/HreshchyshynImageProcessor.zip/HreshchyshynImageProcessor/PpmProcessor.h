#ifndef PPM_PROCESSOR_H
#define PPM_PROCESSOR_H
#include "PixelProcessor.h"
struct PPM_Header{
    //TODO:Finish struct
    /*char magic_number[2]; // should be of size 2.
    char magic_whitespace; // hopefully a newline
    char width;
    char width_whitespace; // hopefully a space
    char height;
    char height_whitespace; // hopefully a newline
    char max_color_value[5]; //each element stores a digit of the number. Most significant is first element. Least significant is last element. Less than 65536 and greater than 0.
    char max_color_whitespace; // hopefully a newline*/
    char magic_number[3];
    int width;
    int height;
    /*int*/unsigned char max_color_value;
    /*char width[1048];
    char height[1048];
    char max_color_value[5];*/
};

/**
 * read PPM header of a file. Useful for converting files from BMP to PPM.
 *
 * @param  file: A pointer to the file being read or written
 * @param  header: Pointer to the destination PPM header
 */
void readPPMHeader(FILE* file, struct PPM_Header* header);

/**
 * write PPM header of a file. Useful for converting files from BMP to PPM.
 *
 * @param  file: A pointer to the file being read or written
 * @param  header: The header to write to the file

 */
void writePPMHeader(FILE* file, struct PPM_Header* header);

/**
 * make PPM header based on width and height. Useful for converting files from BMP to PPM.
 *
 * @param  header: Pointer to the destination PPM header
 * @param  width: Width of the image that this header is for
 * @param  height: Height of the image that this header is for
 */
void makePPMHeader(struct PPM_Header* header, int width, int height);

/**
 * read Pixels from PPM file based on width and height.
 *
 * @param  file: A pointer to the file being read
 * @param  pArr: Pixel array to store the pixels being read
 * @param  width: Width of the pixel array of this image
 * @param  height: Height of the pixel array of this image
 */
void readPixelsPPM(FILE* file, struct Pixel** pArr, int width, int height);

/**
 * write Pixels from PPM file based on width and height.
 *
 * @param  file: A pointer to the file being read or written
 * @param  pArr: Pixel array of the image to write to the file
 * @param  width: Width of the pixel array of this image
 * @param  height: Height of the pixel array of this image
 */
void writePixelsPPM(FILE* file, struct Pixel** pArr, int width, int height);

#endif
