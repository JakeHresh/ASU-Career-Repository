#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "BmpProcessor.h"
//#include "PixelProcessor.h"

/**
 * read BMP header of a file. Useful for converting files from PPM to BMP.
 *
 * @param  file: A pointer to the file being read
 * @param  header: Pointer to the destination BMP header
 */
void readBMPHeader(FILE* file, struct BMP_Header* header) // COMPLETE. Correctly reads header info for BMP
{
    // Take information from file and store it into BMP_Header pointer, which has already been created
    // Ensure that the file is being read with mode "rb"
    fseek(file, 0, SEEK_SET);
    fread(header->signature, sizeof(char) * 2, 1, file);
    fread(&header->size, sizeof(int), 1, file); // make sure to pass in address of struct variable
    fread(&header->reserved1, sizeof(short), 1, file);
    fread(&header->reserved2, sizeof(short), 1, file);
    fread(&header->offset_pixel_array, sizeof(int), 1, file);

}

/**
 * write BMP header of a file. Useful for converting files from PPM to BMP.
 *
 * @param  file: A pointer to the file being written
 * @param  header: The header to write to the file
 */
void writeBMPHeader(FILE* file, struct BMP_Header* header) // seems COMPLETE
{
    fseek(file, 0, SEEK_SET);
    /*char test[2] = {'B','M'};
    char* test2 = (char*)malloc(sizeof(char)*2);
    test[0] = 'B';
    test[1] = 'M';*/
    fwrite(header->signature, sizeof(char) * 2, 1, file);
    //fwrite(test2, sizeof(char) * 2, 1, file);
    fwrite(&header->size, sizeof(int), 1, file);
    fwrite(&header->reserved1, sizeof(short), 1, file);
    fwrite(&header->reserved2, sizeof(short), 1, file);
    fwrite(&header->offset_pixel_array, sizeof(int), 1, file);
}

/**
 * read DIB header from a file. Useful for converting files from PPM to BMP.
 *
 * @param  file: A pointer to the file being read
 * @param  header: Pointer to the destination DIB header
 */
void readDIBHeader(FILE* file, struct DIB_Header* header) // correctly reads dib header info. ONLY USE AFTER READING HEADER
{
    fread(&header->dib_header_size, sizeof(int), 1, file); // check to make sure array address is working properly
    fread(&header->image_width, sizeof(int), 1, file); // make sure to pass in address of struct variable
    fread(&header->image_height, sizeof(int), 1, file);
    fread(&header->planes, sizeof(short), 1, file);
    fread(&header->bits_per_pixel, sizeof(short), 1, file);
    fread(&header->compression, sizeof(int), 1, file); // check to make sure array address is working properly
    fread(&header->image_size, sizeof(int), 1, file); // make sure to pass in address of struct variable
    fread(&header->x_pixels_per_meter, sizeof(int), 1, file);
    fread(&header->y_pixels_per_meter, sizeof(int), 1, file);
    fread(&header->colors_in_color_table, sizeof(int), 1, file);
    fread(&header->important_color_count, sizeof(int), 1, file);
}

/**
 * write DIB header of a file. Useful for converting files from PPM to BMP.
 *
 * @param  file: A pointer to the file being written
 * @param  header: The header to write to the file
 */
void writeDIBHeader(FILE* file, struct DIB_Header* header) // ONLY USE AFTER WRITING HEADER. seems COMPLETE
{
    fwrite(&header->dib_header_size, sizeof(int), 1, file); // check to make sure array address is working properly
    fwrite(&header->image_width, sizeof(int), 1, file); // make sure to pass in address of struct variable
    fwrite(&header->image_height, sizeof(int), 1, file);
    fwrite(&header->planes, sizeof(short), 1, file);
    fwrite(&header->bits_per_pixel, sizeof(short), 1, file);
    fwrite(&header->compression, sizeof(int), 1, file);
    fwrite(&header->image_size, sizeof(int), 1, file);
    fwrite(&header->x_pixels_per_meter, sizeof(int), 1, file);
    fwrite(&header->y_pixels_per_meter, sizeof(int), 1, file);
    int colors = 0;
    //fwrite(&header->colors_in_color_table, sizeof(int), 1, file);
    fwrite(&colors, sizeof(int), 1, file);//this is new
    fwrite(&header->important_color_count, sizeof(int), 1, file);
}

/**
 * make BMP header based on width and height.
 * The purpose of this is to create a new BMPHeader struct using the information
 * from a PPMHeader when converting from PPM to BMP.
 *
 * @param  header: Pointer to the destination DIB header
 * @param  width: Width of the image that this header is for
 * @param  height: Height of the image that this header is for
 */
void makeBMPHeader(struct BMP_Header* header, int width, int height) // complete for now
{
    header->signature[0] = 'B';
    header->signature[1] = 'M';
    //calculate file size
    //check if the (width * 3) is mod 4. If not, add 1 and check again. Keep doing this until you have row size.
    //once you have row size, multiply row size by height, giving entire file size.
    //also remember to add 54 bytes to size to account for size of header and dib.
    int row_size;
    row_size = width * 3;
    while(row_size%4 != 0)
    {
        row_size++;
    }
    int file_size = (row_size * height) + 54;
    header->size = file_size;
    header->reserved1 = 0;
    header->reserved2 = 0;
    //file offset to pixel array should be 54 bytes since there are 14 bytes of the header plus an additional 40 bytes of the dib before the pixel array
    header->offset_pixel_array = 54;
}


/**
* Makes new DIB header based on width and height. Useful for converting files from PPM to BMP.
*
* @param  header: Pointer to the destination DIB header
* @param  width: Width of the image that this header is for
* @param  height: Height of the image that this header is for
*/
void makeDIBHeader(struct DIB_Header* header, int width, int height) // complete for now
{
    //dib header size should be 40 bytes
    header->dib_header_size = 40;
    header->image_width = width;
    header->image_height = height;
    header->planes = 1;
    // there are 8 bits in 1 pixel color. Each pixel has 3 colors. 8 bits * 3 colors = 24 bits per pixel
    header->bits_per_pixel = 24;
    header->compression = 0;
    //calculate row size. Check if width is mod 4. if not, add 1 until it is. multiply row size by height to get image size
    int row_size = width * 3;
    while(row_size%4 != 0)
    {
        row_size++;
    }
    int image_size = row_size * height;
    header->image_size = image_size;
    header->x_pixels_per_meter = 0;// check to calculate this later
    header->y_pixels_per_meter = 0;// check to calculate this later
    header->colors_in_color_table = 0;
    header->important_color_count = 0;
}


/**
 * read Pixels from BMP file based on width and height.
 *
 * @param  file: A pointer to the file being read
 * @param  pArr: Pixel array to store the pixels being read
 * @param  width: Width of the pixel array of this image
 * @param  height: Height of the pixel array of this image
 */
void readPixelsBMP(FILE* file, struct Pixel** pArr, int width, int height) // works correctly
{
    // needs to navigate around padding. 1st, calculate row size. Then
    // calculate the padding. Then use row size and height to loop
    // through pixel array, reading info from file into each visited element
    // use fseek to skip through padding
    int row_size = width * 3; // 3 bytes per pixel in row
    int pad_size = 0;
    while(row_size%4 != 0)
    {
        row_size++;
        pad_size++;
    }
    //results in variable containing size of row in bytes with padding. pad_size also tracks the number of padding bytes.
    for(int i = 0; i < height; i++) // visit each element of pixel array and initialize r g b values of pixels by using fread. LAST BYTE IS READ FIRST in B G R order
    {
        for(int j = 0; j < width; j++)
        {
            fread(&pArr[j][i].blue_byte, sizeof(char), 1, file);//[j][i] so that all the information in row is stored
            fread(&pArr[j][i].green_byte, sizeof(char), 1, file);
            fread(&pArr[j][i].red_byte, sizeof(char), 1, file);
        }
        fseek(file, pad_size, SEEK_CUR);// skips padding.
    }
}


/**
 * write Pixels from BMP file based on width and height.
 *
 * @param  file: A pointer to the file being read or written
 * @param  pArr: Pixel array of the image to write to the file
 * @param  width: Width of the pixel array of this image
 * @param  height: Height of the pixel array of this image
 */
void writePixelsBMP(FILE* file, struct Pixel** pArr, int width, int height) // writing complete. I can now copy an existing bmp image file into a new one.
{
    int row_size = width * 3; // 3 bytes per pixel in row
    int pad_size = 0;
    char pad = 0;
    while(row_size%4 != 0)
    {
        row_size++;
        pad_size++;
    }
    //results in variable containing size of row in bytes with padding. pad_size also tracks the number of padding bytes.
    for(int i = 0; i < height; i++) // visit each element of pixel array and initialize r g b values of pixels by using fread. LAST BYTE IS READ FIRST in B G R order
    {
        int temp_pad = pad_size;
        for(int j = 0; j < width; j++)
        {
            fwrite(&pArr[j][i].blue_byte, sizeof(char), 1, file);//[j][i] so that all the information in row is stored
            fwrite(&pArr[j][i].green_byte, sizeof(char), 1, file);
            fwrite(&pArr[j][i].red_byte, sizeof(char), 1, file);
        }
        //fseek(file, pad_size, SEEK_CUR);// skips padding.
        while(temp_pad > 0)
        {
            fwrite(&pad, sizeof(char), 1, file);
            temp_pad--;
        }
    }
}