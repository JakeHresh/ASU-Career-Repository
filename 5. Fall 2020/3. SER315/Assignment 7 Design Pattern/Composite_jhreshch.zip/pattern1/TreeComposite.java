import java.util.LinkedList;

public class TreeComposite extends Tree{
	String name;
	private LinkedList<Tree> leftTree;
	private LinkedList<Tree> rightTree;
	public TreeComposite(int num) 
	{
		this.name = "person" + num;
		this.leftTree = new LinkedList<Tree>();
		this.rightTree = new LinkedList<Tree>();
	}
	public void print()
	{
		for(Tree t : leftTree)
		{
			t.print();
		}
		for(Tree r : rightTree)
		{
			r.print();
		}
	}
	public void addLeft(Tree t)
	{
		leftTree.add(t);
	}
	public void addRight(Tree t)
	{
		rightTree.add(t);
	}
}
