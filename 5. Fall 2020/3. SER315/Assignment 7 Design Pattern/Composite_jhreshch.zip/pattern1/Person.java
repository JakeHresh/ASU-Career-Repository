
public class Person extends Tree {
    String name;
    
    public Person(int num) {
        name = "person" + num;
    }
    
    public void print() {
        System.out.println(name);
    }
}
