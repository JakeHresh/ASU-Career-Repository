import java.util.Random;

public class Elf extends Species {
    public Elf(String name) {
        this.name = name;
        this.strength = 4;
        this.resilience = 2;
        this.charac = this;
        this.characterSpecies = "Elf";
    }
    public int attackEnemy()
    {
    	int damageDealt;
    	Random random = new Random();
    	int spellDamage = random.nextInt();
    	damageDealt = this.strength + spellDamage;
    	return damageDealt;
    }
}
