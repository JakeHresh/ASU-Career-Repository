public class Species extends Character
{
	protected Character charac;
	protected String characterSpecies;
}
