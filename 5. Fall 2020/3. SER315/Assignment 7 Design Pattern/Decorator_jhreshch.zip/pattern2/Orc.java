import java.util.Random;

public class Orc extends Species {
    public Orc(String name) {
        this.name = name;
        this.strength = 10;
        this.resilience = 9;
        this.charac = this;
        this.characterSpecies = "Orc";
    }
    public int takeHit()
    {
    	Random random = new Random();

        int damageDealt = random.nextInt(15);
        int damageTaken;
        double chanceToDodge = random.nextDouble();

        if (chanceToDodge > 0.50) {
            damageTaken = 0;
        } else {
            damageTaken = damageDealt - resilience;
        }
        damageTaken = damageDealt - resilience;

        if (damageTaken < 0) {
            damageTaken = 0;
        }
        return damageTaken;
    }
}
