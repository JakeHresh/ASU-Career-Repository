import java.util.LinkedList;

public class Employee {
	private int id;
	private PurchaseOrderCollection purchaseOrderCollection;
	private LinkedList<PurchaseOrderCollection.Redo> redoCollection;
	public Employee(int id, PurchaseOrderCollection purchaseOrderCollection)
	{
		this.id = id;
		this.purchaseOrderCollection = purchaseOrderCollection;
		this.redoCollection = new LinkedList<PurchaseOrderCollection.Redo>();
	}
	public void requestPurchaseOrder(int quantity)
	{
		redoCollection.add(purchaseOrderCollection.recordState());
		purchaseOrderCollection.addToCollection(new PurchaseOrder(quantity));
		//redoCollection.add(purchaseOrderCollection.recordState());
		System.out.println("Purchase Order Requested.");
	}
	public void undoRecentPurchaseOrderRequest()
	{
		purchaseOrderCollection.restoreState(redoCollection.removeLast());
	}
}
