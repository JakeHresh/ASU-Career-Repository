
public class Main {
	public static void main(String[] args) {
		//System.out.println("Hello");
		
		PurchaseOrderCollection pCol = new PurchaseOrderCollection();
		Employee Jerry = new Employee(3, pCol);
		Jerry.requestPurchaseOrder(1);
		Jerry.requestPurchaseOrder(5);
		pCol.print();
		Jerry.undoRecentPurchaseOrderRequest();
		pCol.print();
	}
}
