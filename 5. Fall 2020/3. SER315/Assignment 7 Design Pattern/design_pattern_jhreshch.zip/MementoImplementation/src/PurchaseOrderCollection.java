import java.util.LinkedList;

public class PurchaseOrderCollection {
	private LinkedList<PurchaseOrder> purchaseOrders;
	public PurchaseOrderCollection()
	{
		purchaseOrders = new LinkedList<PurchaseOrder>();
	}
	public static class Redo{
		private LinkedList<PurchaseOrder> purchaseOrders;
		public Redo(LinkedList<PurchaseOrder> purchaseOrders)
		{
			this.purchaseOrders = new LinkedList<PurchaseOrder>();
			for(PurchaseOrder p : purchaseOrders)
			{
				PurchaseOrder purch = new PurchaseOrder(p.quantity);
				this.purchaseOrders.add(purch);
			}
		}
	}
	public void addToCollection(PurchaseOrder p)
	{
		purchaseOrders.add(p);
		System.out.println("Purchase Order Added");
	}
	public Redo recordState()
	{
		System.out.println("State Recorded");
		return new Redo(this.purchaseOrders);
	}
	public void restoreState(Redo r)
	{
		System.out.println("State Restored");
		this.purchaseOrders.clear();
		for(PurchaseOrder p : r.purchaseOrders)
		{
			this.purchaseOrders.add(p);
		}
	}
	public void print()
	{
		for(PurchaseOrder p : this.purchaseOrders)
		{
			p.print();
		}
	}
}
