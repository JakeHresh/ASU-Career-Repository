public class PurchaseOrder {
	int quantity;
	public PurchaseOrder(int quantity)
	{
		this.quantity = quantity;
	}
	public void print()
	{
		System.out.println("Quantity: " + this.quantity);
	}
}
