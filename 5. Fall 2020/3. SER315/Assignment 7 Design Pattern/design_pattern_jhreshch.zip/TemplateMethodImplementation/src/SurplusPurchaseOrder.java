public class SurplusPurchaseOrder extends PurchaseOrderTemplate{
	
	@Override
	public void sendExpedited() {
		System.out.println("Sending standard shipment order.");
	}

	@Override
	public void sendSurplus() {
		System.out.println("Overweight. Fees incurred.");
	}

}
