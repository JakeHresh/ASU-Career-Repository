
public class Main {
	public static void main(String[] args) {
		Employee Jerry = new Employee(3);
		Jerry.requestPurchaseOrder(3, true);
		Jerry.requestPurchaseOrder(6, false);
	}
}
