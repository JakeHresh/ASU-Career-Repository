import java.util.LinkedList;

public class Employee 
{
	int id;
	LinkedList<PurchaseOrderTemplate> templates;
	public Employee(int id)
	{
		this.id = id;
		templates = new LinkedList<PurchaseOrderTemplate>();
	}
	public void requestPurchaseOrder(int quantity, boolean expedited)
	{
		PurchaseOrderTemplate p;
		if(quantity > 5)
		{
			System.out.println("working through surplus order");
			p = new SurplusPurchaseOrder();
			p.processPurchase(quantity, expedited);
			templates.add(p);
		}
		else if(expedited)
		{
			System.out.println("working through expedited order");
			p = new ExpeditedShippingOrder();
			p.processPurchase(quantity, expedited);
			templates.add(p);
		}
	}
}
