
public class ExpeditedShippingOrder extends PurchaseOrderTemplate 
{
	@Override
	public void sendExpedited() {
		System.out.println("Sending expedited shipment.");
	}

	@Override
	public void sendSurplus() {
		System.out.println("Item is below surplus. No weight fees.");
	}

}
