public abstract class PurchaseOrderTemplate 
{
	int quantity;
	public abstract void sendExpedited();
	public abstract void sendSurplus();
	public void processPurchase(int quantity, boolean expedited)
	{
		System.out.println("Processing order");
		if(quantity > 5)
		{
			sendSurplus();
		}
		else if(expedited)
		{
			sendExpedited();
		}
		else if(quantity <= 5 && !expedited)
		{
			System.out.println("Processing standard shipping order");
		}
	}
}
