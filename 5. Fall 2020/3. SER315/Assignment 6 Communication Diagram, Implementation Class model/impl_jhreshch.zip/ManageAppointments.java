import java.time.LocalDateTime;
import java.util.LinkedList;

public class ManageAppointments {
	private LinkedList<Appointment> Appointment;// = new LinkedList<>();
	private TutoringRoom r;
	private ManageAccount maccount;
	private LocalDateTime now = LocalDateTime.now();
	public ManageAppointments()
	{
		Appointment = new LinkedList<>();
		r = new TutoringRoom();
		maccount = new ManageAccount();
	}
	public ManageAccount getAccountManager()
	{
		return maccount;
	}
	public LinkedList<Appointment> getAppointments()
	{
		return Appointment;
	}
	public void createAppointment(String email, LocalDateTime time, boolean online)
	{
		// assuming tutor is found
		Tutor t = null;
		for(Tutor tut : maccount.getTutors()/*accountManager.tutors*/)
		{
			if(email.equals(tut.getEmail()/*tut.email*/))
			{
				t = tut;
				break;
			}
		}
		if(t == null)
		{
			System.out.println("Tutor not found.");
		}
		if(!online)
		{
			int count = 0;
			for(Appointment campusApp/*onlineApp*/ : t.getAppointments()/*tempTut.appointments*/)
			{
				if(!campusApp/*onlineApp*/.isOnline())
				{
					count++;
				}
			}
			boolean already5 = count >=5;
			if(already5)
			{
				System.out.println("Already 5 appointments at this time.");
			}
			else
			{
				//System.out.println("Appointment created");
				CampusAppointment ca = new CampusAppointment(time);
				/*newOnlineApp.tutor = tempTut;*/
				ca.setTutor(t);
				Appointment.add(ca);
				/*tempTut.appointments.add(newOnlineApp);*/
				t.addAppointment(ca);
				r.addAppointment(ca);
				System.out.println("Appointment created");
			}
		}
		else
		{
			//System.out.println("Appointment created");
			OnlineAppointment oa = new OnlineAppointment(time);
			/*newCampApp.tutor = tempTut;*/
			oa.setTutor(t);
			Appointment.add(oa);
			/*tempTut.appointments.add(newCampApp);*/
			t.addAppointment(oa);
			System.out.println("Appointment created");
		}
	}
	
	public String cancelAppointment(int appointmentId, String email, boolean isSick){
        Student tempStu = null;

        //find student in list of students from the system
        //we assume student exists=
        for(Student stu : maccount.getStudents()/*accountManager.students*/) {//change to accountManager.students
            if(email.equals(stu.getEmail()/*stu.email*/)){
                tempStu = stu;
                break;
            }
        }

        //find appointment in list of appointment from system
        //we assume appointment exists
        Appointment tempApp = null;
        for(Appointment app : Appointment) {
            if (appointmentId == app.getAppointmentId()/*app.appointmentId*/) {
                tempApp = app;
                break;
            }
        }

        String event;

        if(!tempStu.getAppointments().contains(tempApp)/*!tempStu.appointments.contains(tempApp)*/){
            event = "Student is not registered for appointment with id: " + appointmentId + "\n"; // id of appointment added not 100% consistent to SD but helps clarify what happened
        }
        else {
            //if Appointment is < 24 hours before appointment Start Time.
            if(tempApp.getStartTime().minusHours(24).isBefore(now)/*tempApp.startTime.minusHours(24).isBefore(now)*/) {
                if(isSick) {
                    event = "Student: Appointment cancelled provide proof for refund\n" +
                    "Tutor: Appointment with ID: " + appointmentId+ " has been cancelled by student\n"; // id of appointment added not 100% consistent to SD but helps clarify what happened
                } else {
                    event = "Student: Appointment Cancelled, no refund issued\n" +
                    "Tutor: Appointment with ID: " + appointmentId+ " has been cancelled by student\n"; // id of appointment added not 100% consistent to SD but helps clarify what happened
                }
            } else {
                event = "Student: Appointment Cancelled, refund issued\n" +
                "Tutor: Appointment with ID: " + appointmentId+ " has been cancelled by student\n";
            }
        }
        return event;
    }
}
