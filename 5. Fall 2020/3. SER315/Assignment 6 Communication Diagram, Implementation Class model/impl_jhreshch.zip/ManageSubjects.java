import java.util.LinkedList;

public class ManageSubjects {
	private LinkedList<Subject> subjects;
	public ManageSubjects()
	{
		subjects = new LinkedList<>();
	}
	public void addSubject(Subject s)
	{
		subjects.add(s);
	}
	public LinkedList<Subject> getSubjects()
	{
		return subjects;
	}
}
