/**
 * OnlineAppointment class represents a virtual tutoring appointment. 
 */
import java.time.LocalDateTime;
import java.util.Random;

public class OnlineAppointment extends Appointment{

    public OnlineAppointment(LocalDateTime startTime){
        /*this.startTime = startTime;*/
        this.setStartTime(startTime);
    	Random rand = new Random(); 
        /*this.appointmentId = rand.nextInt();*/ //maybe not perfect but you can come up with alternatives
        this.setAppointmentId(rand.nextInt());
    	/*this.student = null;*/
        this.setStudent(null);
        /*this.tutor = null;*/
        this.setTutor(null);
        /*super.isOnline = true;*/
        super.setIsOnline(true);
    }
}