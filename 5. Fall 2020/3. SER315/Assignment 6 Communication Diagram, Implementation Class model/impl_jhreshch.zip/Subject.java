/**
 * Subject class represents a subject for which a tutor can offer to teach. 
 */
import java.util.LinkedList;

public class Subject{
    private String name;
    private Manager manager;
    private LinkedList<Tutor> tutors;

    public Subject(String name){
        this.name = name;
        this.tutors = new LinkedList<>();
    }
}