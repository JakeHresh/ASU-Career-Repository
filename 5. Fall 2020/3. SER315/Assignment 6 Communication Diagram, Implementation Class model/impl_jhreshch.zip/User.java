/**
 * User class represents the base user in our system. 
 */
public abstract class User{
    private String userName; 
    private String password; 
    private String email; 
    public void setUserName(String n)
    {
    	userName = n;
    }
    public void setPassword(String p)
    {
    	password = p;
    }
    public void setEmail(String e)
    {
    	email = e;
    }
    public String getUserName()
    {
    	return userName;
    }
    public String getPassword()
    {
    	return password;
    }
    public String getEmail()
    {
    	return email;
    }
}