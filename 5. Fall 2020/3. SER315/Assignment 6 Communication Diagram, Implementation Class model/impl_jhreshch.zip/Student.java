import java.util.LinkedList;
public class Student extends User{
    private int credits;
    private LinkedList<Appointment> appointments;
    private PaymentCard paymentCard;

    public Student(String userName, String email, String password){

        /*this.userName = userName;*/
        this.setUserName(userName);
    	/*this.email = email;*/
        this.setEmail(email);
        /*this.password = password;*/
        this.setPassword(password);
        
        this.paymentCard = new PaymentCard();
        this.appointments = new LinkedList<>();
        this.credits = 0;
    }
    public LinkedList<Appointment> getAppointments()
    {
    	return appointments;
    }
}