/**
 * CampusAppointment class represents a tutoring appointment that will be held in person at the school. 
 */

import java.time.LocalDateTime;
import java.util.Random;

public class CampusAppointment extends Appointment{
    public CampusAppointment(LocalDateTime startTime){
        /*this.startTime = startTime;*/
    	this.setStartTime(startTime);
        Random rand = new Random();
        /*this.appointmentId = rand.nextInt();*/ //maybe not perfect but you can come up with alternatives
        this.setAppointmentId(rand.nextInt());
        //this.student = null;
        this.setStudent(null);
        //this.tutor = null;
        this.setTutor(null);
        this.setIsOnline(false);
    } 
}