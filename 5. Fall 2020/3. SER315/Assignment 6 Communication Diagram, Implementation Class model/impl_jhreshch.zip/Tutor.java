/**
 * Tutor class represents a tutor type user in the system. Tutors are responsible for signing up to teach subjects, as well as creating appointments for students to book. 
 */
import java.util.LinkedList;
public class Tutor extends User{
    private String zoomId;
    private LinkedList<Subject> subjects;
    private LinkedList<Appointment> appointments;

    public Tutor(String userName, String email, String password) {
        /*this.userName = userName;*/
    	this.setUserName(userName);
        /*this.email = email;*/
    	this.setEmail(email);
        /*this.password = password;*/
    	this.setPassword(password);
        this.zoomId = null;
        this.subjects = new LinkedList<>();
        this.appointments = new LinkedList<>();
    }
    public LinkedList<Appointment> getAppointments()
    {
    	return appointments;
    }
    public void addAppointment(Appointment a)
    {
    	appointments.add(a);
    }
    public void addSubject(Subject s)
    {
    	subjects.add(s);
    }
}