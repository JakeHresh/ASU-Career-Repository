import java.util.LinkedList;

public class ManageAccount {
	private LinkedList<Student> students;// = new LinkedList<>();
	private LinkedList<Tutor> tutors;// = new LinkedList<>();
	private LinkedList<Manager> managers;// = new LinkedList<>();
	private ManageSubjects subjectManager;
	public ManageAccount()
	{
		students = new LinkedList<>();
		tutors = new LinkedList<>();
		managers = new LinkedList<>();
		subjectManager = new ManageSubjects();
	}
	public ManageSubjects getSubjectManager()
	{
		return subjectManager;
	}
	public LinkedList<Student> getStudents()
	{
		return students;
	}
	public LinkedList<Tutor> getTutors()
	{
		return tutors;
	}
	public void addManager(Manager m)
	{
		managers.add(m);
	}
	public void addTutor(Tutor t)
	{
		tutors.add(t);
	}
	public void addStudent(Student s)
	{
		students.add(s);
	}
}
