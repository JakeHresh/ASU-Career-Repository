/**
 * Appointment represents the base appointment in our system. 
 */

import java.time.LocalDateTime;
import java.util.Random;
public  class Appointment{
    private int id;
    private LocalDateTime time;
    private Student student;
    private Tutor tutor;
	private boolean isOnline;
	public Appointment()
	{
		id = -1;
		time = null;
		student = null;
		tutor = null;
		isOnline = false;
	}
	public void setAppointmentId(int id)
	{
		this.id = id;
	}
	public void setStartTime(LocalDateTime time)
	{
		this.time = time;
	}
	public void setStudent(Student s)
	{
		student = s;
	}
	public void setTutor(Tutor t)
	{
		tutor = t;
	}
	public void setIsOnline(boolean i)
	{
		isOnline = i;
	}
	public int getAppointmentId()
	{
		return id;
	}
	public LocalDateTime getStartTime()
	{
		return time;
	}
	public Student getStudent()
	{
		return student;
	}
	public Tutor getTutor()
	{
		return tutor;
	}
	public boolean isOnline()
	{
		return isOnline;
	}
}