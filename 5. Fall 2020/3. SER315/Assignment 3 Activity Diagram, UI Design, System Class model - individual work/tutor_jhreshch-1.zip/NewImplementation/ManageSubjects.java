import java.util.LinkedList;

public class ManageSubjects {
	public LinkedList<Subject> subjects;
	public ManageSubjects()
	{
		subjects = new LinkedList<>();
	}
}
