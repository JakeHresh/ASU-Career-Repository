import java.util.LinkedList;

public class ManageAccount {
	public LinkedList<Student> students;// = new LinkedList<>();
	public LinkedList<Tutor> tutors;// = new LinkedList<>();
	public LinkedList<Manager> managers;// = new LinkedList<>();
	public ManageSubjects subjectManager;
	public ManageAccount()
	{
		students = new LinkedList<>();
		tutors = new LinkedList<>();
		managers = new LinkedList<>();
		subjectManager = new ManageSubjects();
	}
}
