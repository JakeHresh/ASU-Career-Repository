import java.time.LocalDateTime;
import java.util.LinkedList;

public class ManageAppointments {
	public LinkedList<Appointment> appointments;// = new LinkedList<>();
	public TutoringRoom t_room;
	public ManageAccount accountManager;
	public LocalDateTime now = LocalDateTime.now();
	public ManageAppointments()
	{
		appointments = new LinkedList<>();
		t_room = new TutoringRoom();
		accountManager = new ManageAccount();
	}
	public void createAppointment(String email, LocalDateTime time, boolean online)
	{
		// assuming tutor is found
		Tutor tempTut = null;
		for(Tutor tut : accountManager.tutors)
		{
			if(email.equals(tut.email))
			{
				tempTut = tut;
				break;
			}
		}
		if(online)
		{
			int onlineCount = 0;
			for(Appointment onlineApp : tempTut.appointments)
			{
				if(onlineApp.isOnline)
				{
					onlineCount++;
				}
			}
			if(onlineCount >= 5)
			{
				System.out.println("Already 5 appointments at this time.");
			}
			else
			{
				System.out.println("Online appointment created.");
				OnlineAppointment newOnlineApp = new OnlineAppointment(time);
				newOnlineApp.tutor = tempTut;
				appointments.add(newOnlineApp);
				tempTut.appointments.add(newOnlineApp);
			}
		}
		else
		{
			System.out.println("Campus appointment created.");
			CampusAppointment newCampApp = new CampusAppointment(time);
			newCampApp.tutor = tempTut;
			appointments.add(newCampApp);
			tempTut.appointments.add(newCampApp);
		}
	}
	
	public String cancelAppointment(int appointmentId, String email, boolean isSick){
        Student tempStu = null;

        //find student in list of students from the system
        //we assume student exists
        for(Student stu : accountManager.students) {//change to accountManager.students
            if(email.equals(stu.email)){
                tempStu = stu;
                break;
            }
        }

        //find appointment in list of appointment from system
        //we assume appointment exists
        Appointment tempApp = null;
        for(Appointment app : appointments) {
            if (appointmentId == app.appointmentId) {
                tempApp = app;
                break;
            }
        }

        String event;

        if(!tempStu.appointments.contains(tempApp)){
            event = "Student is not registered for appointment with id: " + appointmentId + "\n"; // id of appointment added not 100% consistent to SD but helps clarify what happened
        }
        else {
            //if Appointment is < 24 hours before appointment Start Time.
            if(tempApp.startTime.minusHours(24).isBefore(now)) {
                if(isSick) {
                    event = "Student: Appointment cancelled provide proof for refund\n" +
                    "Tutor: Appointment with ID: " + appointmentId+ " has been cancelled by student\n"; // id of appointment added not 100% consistent to SD but helps clarify what happened
                } else {
                    event = "Student: Appointment Cancelled, no refund issued\n" +
                    "Tutor: Appointment with ID: " + appointmentId+ " has been cancelled by student\n"; // id of appointment added not 100% consistent to SD but helps clarify what happened
                }
            } else {
                event = "Student: Appointment Cancelled, refund issued\n" +
                "Tutor: Appointment with ID: " + appointmentId+ " has been cancelled by student\n";
            }
        }
        return event;
    }
}
