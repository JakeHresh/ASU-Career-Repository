/**
 * User class represents the base user in our system. 
 */
public abstract class User{
    public String userName; 
    public String password; 
    public String email; 
}