/**
 * Appointment represents the base appointment in our system. 
 */

import java.time.LocalDateTime;
import java.util.Random;
public  class Appointment{
    public int appointmentId;
    public LocalDateTime startTime;
    public Student student;
    public Tutor tutor;
	public boolean isOnline;
	public Appointment()
	{
		appointmentId = -1;
		startTime = null;
		student = null;
		tutor = null;
		isOnline = false;
	}

}