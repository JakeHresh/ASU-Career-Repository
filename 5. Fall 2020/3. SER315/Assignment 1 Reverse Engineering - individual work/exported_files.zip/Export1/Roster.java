public class Roster {

	private Course course;

	private Student[] student;

	public boolean addStudent(Student student) {
		return false;
	}

	public List<Student> getStudents() {
		return null;
	}

	public int getStudentCount() {
		return 0;
	}

}
