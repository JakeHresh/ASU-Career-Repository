public class Double {

}
