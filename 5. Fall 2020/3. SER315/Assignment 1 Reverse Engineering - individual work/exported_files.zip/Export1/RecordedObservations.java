public class RecordedObservations {

	private FieldTrip fieldTrip;

	private Observation[] observation;

	private Student student;

	public int photoObservation(String photoURL) {
		return 0;
	}

	public int photoObservation(String photoURL, Double dLat, Double dLong) {
		return 0;
	}

	public int writeObservation(String summ) {
		return 0;
	}

	public int writeObservation(String summ, String descr) {
		return 0;
	}

	public Student getStudent() {
		return null;
	}

	public List<Observation> getObservations() {
		return null;
	}

	public int getObservationCount() {
		return 0;
	}

	private int addObservation(Observation obs) {
		return 0;
	}

}
