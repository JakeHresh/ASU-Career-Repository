public abstract class Observation {

	private String id;

	private LocalDateTime dateTime;

	private RecordedObservations recordedObservations;

	public String getID() {
		return null;
	}

	public String read() {
		return null;
	}

	public String getDateTime() {
		return null;
	}

}
