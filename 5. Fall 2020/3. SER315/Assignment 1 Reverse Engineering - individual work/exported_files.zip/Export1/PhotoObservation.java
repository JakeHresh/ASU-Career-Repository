public class PhotoObservation extends Observation {

	private String imageURL;

	private Double latitude;

	private Double longitude;

	public String read() {
		return null;
	}

	public String getImageURL() {
		return null;
	}

	public String getLatitude() {
		return null;
	}

	public String getLongitude() {
		return null;
	}

}
