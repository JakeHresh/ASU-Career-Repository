public class Person {

	private String name;

	private String email;

	public String getEmail() {
		return null;
	}

	public String toString() {
		return null;
	}

}
