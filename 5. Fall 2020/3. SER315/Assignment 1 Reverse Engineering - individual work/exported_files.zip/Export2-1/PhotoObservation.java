public class PhotoObservation extends Observation {

	private final String imageURL;

	private final Double latitude;

	private final Double longitude;

	public String read() {
		return null;
	}

	public String getImageURL() {
		return null;
	}

	private String getLatitude() {
		return null;
	}

	private String getLongitude() {
		return null;
	}

}
