import java.time.LocalDateTime;

class Observation {

	private final String id;

	private final LocalDateTime datetime;

	public String getID() {
		return null;
	}

	public String read() {
		return null;
	}

	private String getDatetime() {
		return null;
	}

}
