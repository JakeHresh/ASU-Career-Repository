class Person {

	private final String name;

	private final String email;

	public String getName() {
		return null;
	}

	public String getEmail() {
		return null;
	}

	public String toString() {
		return null;
	}

}
