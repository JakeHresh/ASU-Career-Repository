public class Student extends Person {

	private final String major;

	private final String favColor;

	public String getMajor() {
		return null;
	}

	public String getFavColor() {
		return null;
	}

	public String toString() {
		return null;
	}

}
