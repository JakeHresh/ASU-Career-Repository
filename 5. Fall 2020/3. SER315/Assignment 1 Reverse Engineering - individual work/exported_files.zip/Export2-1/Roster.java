import java.util.List;

public class Roster {

	private final Course course;

	private final List students;

	public boolean addStudent(Student student) {
		return false;
	}

	public List getStudents() {
		return null;
	}

	public int getStudentCount() {
		return 0;
	}

}
