public class Professor extends Person {

	private String phone;

	private String hobby;

	public Professor(String name, String email, String phone, String hobby) {

	}

	public String getPhone() {
		return null;
	}

	public String getHobby() {
		return null;
	}

	public String toString() {
		return null;
	}

	private void setPhone(String phoneNumber) {

	}

}
