import java.util.List;

public class FieldTrip {

	private RecordedObservations[] observations;

	private Course course;

	public FieldTrip(Course course) {

	}

	public int makeWrittenObservation(Student stu, String summ, String descr) {
		return 0;
	}

	public int makePhotoObservation(Student stu, String imgURL, Double dLat, Double dLong) {
		return 0;
	}

	public List<String> getStudentNames() {
		return null;
	}

	public List<RecordedObservations> getObservations() {
		return null;
	}

	public void operation0() {

	}

	public int getObservationCount() {
		return 0;
	}

	private RecordedObservations getRecordedObservations(Student stu) {
		return null;
	}

}
