package java.lang;

public class String {

}
