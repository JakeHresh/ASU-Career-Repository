package java.util;

public interface List<E> {

}
