import java.time.LocalDateTime;

public abstract class Observation {

	private String id;

	private LocalDateTime datetime;

	Observation() {

	}

	public String getID() {
		return null;
	}

	public String read() {
		return null;
	}

	private String getDatetime() {
		return null;
	}

}
