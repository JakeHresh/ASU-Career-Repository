
public class Credit 
{
	public Credit()
	{
		
	}
}
