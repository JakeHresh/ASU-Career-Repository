import java.util.ArrayList;

public class Tutor 
{
	public String username;
	public String email;
	public String password;
	public String meetingID;
	public ArrayList<Manager> managers;
	public ArrayList<Subject> subjects;
	public Tutor()
	{
		username = "";
		email = "";
		password = "";
		meetingID = "";
		managers = new ArrayList<Manager>();
		subjects = new ArrayList<Subject>();
	}
	public Tutor(String u, String e, String p, String id, ArrayList<Manager> m, ArrayList<Subject> s)
	{
		username = u;
		email = e;
		password = p;
		meetingID = id;
		managers = new ArrayList<Manager>();
		subjects = new ArrayList<Subject>();
		for(int i = 0; i < m.size(); i++)
		{
			managers.set(i, m.get(i));
		}
		for(int i = 0; i < s.size(); i++)
		{
			subjects.set(i, s.get(i));
		}
	}
}
