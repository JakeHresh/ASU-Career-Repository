import java.util.ArrayList;

public class Subject 
{
	public String subjectName;
	public ArrayList<Manager> managers;
	public ArrayList<Tutor> tutors;
	public OnlineAppointment onlineAppointment;
	public CampusAppointment campusAppointment;
	public Subject()
	{
		subjectName = "";
		managers = new ArrayList<Manager>();
		tutors = new ArrayList<Tutor>();
		onlineAppointment = null;
		campusAppointment = null;
	}
	public Subject(String s, ArrayList<Manager> m, ArrayList<Tutor> t, OnlineAppointment o, CampusAppointment c)
	{
		subjectName = s;
		managers = new ArrayList<Manager>();
		tutors = new ArrayList<Tutor>();
		for(int i = 0; i < m.size(); i++)
		{
			managers.set(i, m.get(i));
		}
		for(int i = 0; i < t.size(); i++)
		{
			tutors.set(i, t.get(i));
		}
		onlineAppointment = o;
		campusAppointment = c;
	}
}
