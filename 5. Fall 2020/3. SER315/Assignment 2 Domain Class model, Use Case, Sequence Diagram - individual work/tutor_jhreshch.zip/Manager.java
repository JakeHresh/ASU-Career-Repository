import java.util.ArrayList;
public class Manager 
{
	public String username;
	public String password;
	public ArrayList<Tutor> tutors;
	public ArrayList<Subject> subjects;
	public Manager()
	{
		username = "";
		password = "";
		tutors = new ArrayList<Tutor>();
		subjects = new ArrayList<Subject>();
	}
	public Manager(String u, String p, ArrayList<Tutor> l, ArrayList<Subject> s)
	{
		username = u;
		password = p;
		tutors = new ArrayList<Tutor>();
		subjects = new ArrayList<Subject>();
		for(int i = 0; i < l.size(); i++)
		{
			tutors.set(i, l.get(i));
		}
		for(int i = 0; i < s.size(); i++)
		{
			subjects.set(i, s.get(i));
		}
	}
	public void informManager()
	{
		System.out.println("Review student evidence for late appointment cancellation.");
	}
}
