import java.util.ArrayList;
public class Student 
{
	public OnlineAppointment onlineAppointment;
	public CampusAppointment campusAppointment;
	public ArrayList<Credit> credit;
	public String username;
	public String email;
	public String password;
	public String paymentInfo;
	public Student()
	{
		onlineAppointment = null;
		campusAppointment = null;
		credit = new ArrayList<Credit>();
		username = "";
		email = "";
		password = "";
		paymentInfo = "";
	}
	public Student(OnlineAppointment o, CampusAppointment camp, ArrayList<Credit> cr, String u, String e, String pass, String pay)
	{
		onlineAppointment = o;
		campusAppointment = camp;
		credit = new ArrayList<Credit>();
		for(int i = 0; i < cr.size(); i++)
		{
			credit.set(i, cr.get(i));
		}
		username = u;
		email = e;
		password = pass;
		paymentInfo = pay;
	}
	
	public void cancelAppointment(String id, String email, String evidence)
	{
		// Assignment says to assume that id and email exist in the system. Therefore, I will not implement checks on that now.
		if(onlineAppointment == null && campusAppointment == null)
		{
			System.out.println("No appointment to cancel.");
			return;
		}
		informTutor();
		
		if(Main.hoursBeforeAppointment > 24)
		{
			cancelNoPenalty();
		}
		else if(evidence.equals(""))
		{
			cancelWithPenalty();
		}
		else
		{
			informManager();
		}
		onlineAppointment = null;
		campusAppointment = null;
	}
	public void allowRefund()
	{
		System.out.println("Refund allowed.");
		cancelNoPenalty();
	}
	public void denyRefund()
	{
		System.out.println("Refund denied.");
		cancelWithPenalty();
	}
	public void cancelNoPenalty()
	{
		System.out.println("Student credit refunded.");
		credit.add(new Credit());
	}
	public void cancelWithPenalty()
	{
		System.out.println("No credit refunded.");
	}
	public void informTutor()
	{
		System.out.println("The student has cancelled his appointment."); // represents informing the tutor
	}
	public void informManager()
	{
		System.out.println("The manager needs to review the student's evidence for cancellation.");
	}
}
