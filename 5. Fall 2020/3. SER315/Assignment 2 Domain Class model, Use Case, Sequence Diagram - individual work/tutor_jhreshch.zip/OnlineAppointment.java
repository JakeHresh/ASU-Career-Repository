import java.util.ArrayList;

public class OnlineAppointment 
{
	public int availableTimeSlots[] = new int[48]; // 48 30 minute timeslots in a 24 hours
	public String appointmentID;
	public Student student;
	public ArrayList<Subject> subjects;
	public OnlineAppointment()
	{
		subjects = new ArrayList<Subject>();
		for(int i = 0; i < availableTimeSlots.length; i++)
		{
			availableTimeSlots[i] = 0; // 0 indicates a slot is free
		}
		appointmentID = "";
		student = null;
	}
	public OnlineAppointment(String a, Student s, ArrayList<Subject> sub)
	{
		subjects = new ArrayList<Subject>();
		for(int i = 0; i < sub.size(); i++)
		{
			subjects.set(i, sub.get(i));
		}
		for(int i = 0; i < availableTimeSlots.length; i++)
		{
			availableTimeSlots[i] = 0; // 0 indicates a slot is free
		}
		appointmentID = a;
		student = s;
	}
}
