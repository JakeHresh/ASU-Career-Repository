import java.util.ArrayList;
public class CampusAppointment 
{
	public int availableTimeSlots[] = new int[20]; // 20 30 minute time slots between 8am and 6pm
	public String appointmentID;
	public Student student;
	public ArrayList<Subject> subjects;
	public CampusAppointment()
	{
		subjects = new ArrayList<Subject>();
		for(int i = 0; i < availableTimeSlots.length; i++)
		{
			availableTimeSlots[i] = 0;
		}
		appointmentID = "";
		student = null;
	}
	public CampusAppointment(String a, Student s, ArrayList<Subject> sub)
	{
		subjects = new ArrayList<Subject>();
		for(int i = 0; i < sub.size(); i++)
		{
			subjects.set(i, sub.get(i));
		}
		for(int i = 0; i < availableTimeSlots.length; i++)
		{
			availableTimeSlots[i] = 0;
		}
		appointmentID = a;
		student = s;
	}
}
