import java.util.*;
public class Main {
	public static int hoursBeforeAppointment = 25;
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		Student student = new Student();
		Tutor tutor = new Tutor();
		Manager manager = new Manager();
		Subject subject = new Subject();
		CampusAppointment campusAppointment = new CampusAppointment();
		OnlineAppointment onlineAppointment = new OnlineAppointment();
		student.campusAppointment = campusAppointment;
		student.onlineAppointment = onlineAppointment;
		onlineAppointment.student = student;
		campusAppointment.student = student;
		//campusAppointment.subjects.set(0, subject);
		campusAppointment.subjects.add(subject);
		onlineAppointment.subjects.add(subject);
		tutor.subjects.add(subject);
		manager.tutors.add(tutor);
		subject.campusAppointment = campusAppointment;
		subject.onlineAppointment = onlineAppointment;
		System.out.println("How many hours is it before the appointment?");
		hoursBeforeAppointment = scan.nextInt();
		System.out.println("Does the student have evidence for cancelling appointment? (Represented as string)");
		scan.nextLine();
		String evidence = scan.nextLine();
		student.cancelAppointment("", "", evidence);
	}
}
