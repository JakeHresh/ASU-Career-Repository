﻿using System;

namespace Lab04
{
    public static class Program
    {
        [STAThread]
        static void Main()
        {
            using (var game = new Lab04())
                game.Run();
        }
    }
}
