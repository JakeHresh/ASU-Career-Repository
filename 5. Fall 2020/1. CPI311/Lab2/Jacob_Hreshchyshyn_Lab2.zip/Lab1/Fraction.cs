﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab1
{
    public struct Fraction
    {
        private int numerator;
        private int denominator;
        public Fraction(int n = 0, int d = 1)
        {
            numerator = n;
            if(d == 0)
            {
                d = 1;
            }
            denominator = d;
            Simplify();
        }

        public override string ToString()
        {
            return numerator + "/" + denominator;
        }

        private void Simplify()
        {
            if(denominator < 0)
            {
                denominator *= 1;
                numerator *= 1;
            }
            int gcd = GCD(numerator, denominator);
            numerator /= gcd;
            denominator /= gcd;
        }
        // overrides the multiplication operator to multiply fraction classes
        public static Fraction operator *(Fraction lhs, Fraction rhs)
        {
            return new Fraction(lhs.numerator * rhs.numerator, lhs.denominator * rhs.denominator);
        }

        public static Fraction operator /(Fraction lhs, Fraction rhs)
        {
            return new Fraction(lhs.numerator * rhs.denominator, lhs.denominator * rhs.numerator);
        }

        public static Fraction operator +(Fraction lhs, Fraction rhs)
        {
            return new Fraction((lhs.numerator * rhs.denominator) + (rhs.numerator * lhs.denominator), rhs.denominator * lhs.denominator);
        }

        public static Fraction operator -(Fraction lhs, Fraction rhs)
        {
            return new Fraction((lhs.numerator * rhs.denominator) - (rhs.numerator * lhs.denominator), rhs.denominator * lhs.denominator);
        }

        public int Numerator
        {
            get { return numerator; }
            set { numerator = value; Simplify(); }
        }

        public int Denominator
        {
            get { return denominator; }
            set { denominator = value; Simplify(); }
        }

        public static int GCD(int a, int b)
        {
            if(a == 0)
            {
                return b;
            }
            return GCD(b%a, a);
        }
    }
}
