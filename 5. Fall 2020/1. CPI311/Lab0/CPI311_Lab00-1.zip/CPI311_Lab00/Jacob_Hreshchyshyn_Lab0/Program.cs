﻿using System;

namespace Jacob_Hreshchyshyn_Lab0
{
    public static class Program
    {
        [STAThread]
        static void Main()
        {
            using (var game = new Game1())
                game.Run();
        }
    }
}
