To build the source code, simply go to the directory src/ser322 and use javac to compile both
JdbcLab.java and Activity2.java.

After building the files, I recommend copying the class files into the classes folder on the
project's root directory and running a command that looks like the following:
java -cp "lib/mysql-connector-java-8.0.23.jar;classes " ser322.JdbcLab "jdbc:mysql://localhost:3306/jdbclab" root " " com.mysql.jdbc.Driver export "filename.xml"

When running Activity2.java, be sure to provide the path of the xml file as a command line
argument in order to parse the file.