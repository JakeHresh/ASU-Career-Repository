package ser322;

import javax.xml.parsers.*;
import org.w3c.dom.*;
import javax.xml.xpath.*;
import java.io.FileInputStream;
import java.io.File;

public class Activity2 {
	public static void main(String[] args) {
		if(args.length > 0) {
			File file = new File(args[0]);
			try
			{
				FileInputStream f = new FileInputStream(file);
				DocumentBuilderFactory fac = DocumentBuilderFactory.newInstance();
				DocumentBuilder builder = fac.newDocumentBuilder();
				Document xml = builder.parse(f);
				XPath x = XPathFactory.newInstance().newXPath();
				String expr = "/Tables/Customer";
				NodeList nodeList = (NodeList) x.compile(expr).evaluate(xml, XPathConstants.NODESET); 
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}
}