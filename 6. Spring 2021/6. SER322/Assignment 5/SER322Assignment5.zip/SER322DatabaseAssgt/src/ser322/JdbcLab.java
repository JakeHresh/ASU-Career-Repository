package ser322;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.regex.Pattern;
import javax.xml.parsers.*;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;

import org.xml.sax.InputSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;


public class JdbcLab {

	public static void main(String[] args) {
		if(args.length == 5)
		{
			if(!args[4].equals("query1"))
			{
				System.out.println("USAGE: ser322.JbdcLab <url> <user> <pwd> <driver> query1");
				System.exit(0);
			}
			query1(args[0], args[1], args[2], args[3]);
		}
		else if(args.length == 6)
		{
			if(!args[4].equals("query2") && !args[4].equals("export"))
			{
				System.out.println("USAGE: ser322.JbdcLab <url> <user> <pwd> <driver> query2 <DeptNo>");
				System.out.println("OR");
				System.out.println("USAGE: ser322.JbdcLab <url> <user> <pwd> <driver> export <filename>");
				System.exit(0);
			}
			else if(args[4].equals("query2"))
				query2(args[0], args[1], args[2], args[3], args[5]);
			else
				export(args[0], args[1], args[2], args[3], args[5]);
		}
		else if(args.length == 9)
		{
			if(!args[4].equals("dml1"))
			{
				System.out.println("USAGE: ser322.JbdcLab <url> <user> <pwd> <driver> dml1 <customer id> <product id> <name> <quantity>");
				System.exit(0);
			}
			dml1(args[0], args[1], args[2], args[3], args[5], args[6], args[7], args[8]);
		}
		else
		{
			System.out.println("USAGE: ser322.JbdcLab <url> <user> <pwd> <driver> query1");
			System.out.println("OR");
			System.out.println("USAGE: ser322.JbdcLab <url> <user> <pwd> <driver> query2 <DeptNo>");
			System.out.println("OR");
			System.out.println("USAGE: ser322.JbdcLab <url> <user> <pwd> <driver> dml1 <customer id> <product id> <name> <quantity>");
			System.exit(0);
		}

	}
	public static void query1(String url, String user, String pwd, String driver)
	{
		ResultSet rs = null;
		Statement stmt = null;
		Connection conn = null;
		try 
		{
			Class.forName(driver);
			if(!pwd.equals(" "))
				conn = DriverManager.getConnection(url, user, pwd);
			stmt = conn.createStatement();
			rs = stmt.executeQuery("Select Distinct E.EMPNO, E.ENAME, D.DNAME From emp AS E, dept AS D Where D.DEPTNO=E.DEPTNO");
			while(rs.next())
			{
				System.out.print(rs.getString(1) + "\t");
				System.out.print(rs.getString(2) + "\t");
				System.out.println(rs.getString(3));
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally 
		{  
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (conn != null)
					conn.close();
			}
			catch (SQLException se) {
				se.printStackTrace();
			}
		}
	}
	public static void query2(String url, String user, String pwd, String driver, String deptNum)
	{
		Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");
		ResultSet rs = null;
		PreparedStatement stmt = null;
		Connection conn = null;
		int dNum = 0;
		if(pattern.matcher(deptNum).matches())
		{
			dNum = Integer.parseInt(deptNum);
		}
		try 
		{
			Class.forName(driver);
			if(!pwd.equals(" "))
				conn = DriverManager.getConnection(url, user, pwd);
			stmt = conn.prepareStatement("Select Distinct C.QUANTITY, D.DNAME, C.NAME, P.PRICE From customer as C, dept as D, product as P Where P.MADE_BY=D.DEPTNO AND P.PRODID=C.PID AND D.DEPTNO=?");
			stmt.setInt(1, dNum);
			rs = stmt.executeQuery();
			while(rs.next())
			{
				System.out.print(rs.getString(2) + "\t");
				System.out.print(rs.getString(3) + "\t");
				//System.out.println(rs.getString(4));
				float spent = Float.parseFloat(rs.getString(1)) * Float.parseFloat(rs.getString(4));
				System.out.println(spent);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally 
		{  
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (conn != null)
					conn.close();
			}
			catch (SQLException se) {
				se.printStackTrace();
			}
		}
	}
	public static void dml1(String url, String user, String pwd, String driver, String customerId, String productId, String name, String quantity)
	{
		Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");
		ResultSet rs = null;
		PreparedStatement stmt = null;
		Connection conn = null;
		int cID = 0;
		int pID = 0;
		int q = 0;
		if(pattern.matcher(customerId).matches())
		{
			cID = Integer.parseInt(customerId);
		}
		if(pattern.matcher(productId).matches())
		{
			pID = Integer.parseInt(productId);
		}
		if(pattern.matcher(quantity).matches())
		{
			q = Integer.parseInt(quantity);
		}
		try 
		{
			Class.forName(driver);
			if(!pwd.equals(" "))
				conn = DriverManager.getConnection(url, user, pwd);
			stmt = conn.prepareStatement("INSERT INTO CUSTOMER VALUES (?, ?, ?, ?);");
			stmt.setInt(1, cID);
			stmt.setInt(2, pID);
			stmt.setString(3, name);
			stmt.setInt(4, q);
			/*rs = */stmt.executeUpdate();
			System.out.println("SUCCESS");
		}
		catch (Exception e)
		{
			System.out.println("Failed to add customer");
			e.printStackTrace();
		}
		finally 
		{  
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (conn != null)
					conn.close();
			}
			catch (SQLException se) {
				se.printStackTrace();
			}
		}
	}
	public static void export(String url, String user, String pwd, String driver, String filename)
	{
		ResultSet rs = null;
		PreparedStatement stmt = null;
		Connection conn = null;
		Document d = null;
		DOMSource dSource = null;

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		try
		{
			DocumentBuilder builder = factory.newDocumentBuilder();
			d = builder.newDocument();
			Element r = d.createElement("Tables");// what if this were the database element
			/*Element dept = d.createElement("Department");
			Element emp = d.createElement("Employee");
			Element prod = d.createElement("Product");*/
			d.appendChild(r);
			try 
			{
				//elements to help in building the xml file
				Element cust = d.createElement("Customer");
				Element dept = d.createElement("Department");
				Element emp = d.createElement("Employee");
				Element prod = d.createElement("Product");
				r.appendChild(cust);
				r.appendChild(dept);
				r.appendChild(emp);
				r.appendChild(prod);

				Class.forName(driver);
				if(!pwd.equals(" "))
					conn = DriverManager.getConnection(url, user, pwd);
				//Setting up Customer
				stmt = conn.prepareStatement("Select CUSTID, PID, NAME, QUANTITY From customer");
				rs = stmt.executeQuery();
				ResultSetMetaData rsmd = rs.getMetaData();

				int columnCount = rsmd.getColumnCount();
				Element tableName = d.createElement("TableName");
				tableName.appendChild(d.createTextNode(rsmd.getTableName(1)));
				cust.appendChild(tableName);

				Element structure = d.createElement("TableStructure");
				cust.appendChild(structure);

				Element col = null;
				for(int i = 1; i <= columnCount; i++)
				{
					col = d.createElement("Column" + 1);
					cust.appendChild(col);
					Element colNode = d.createElement("ColumnName");
					colNode.appendChild(d.createTextNode(rsmd.getColumnName(i)));
					col.appendChild(colNode);

					Element typeNode = d.createElement("ColumnType");
					typeNode.appendChild(d.createTextNode(String.valueOf(rsmd.getColumnTypeName(i))));
					col.appendChild(typeNode);

					Element lengthNode = d.createElement("Length");
					lengthNode.appendChild(d.createTextNode(String.valueOf(rsmd.getPrecision(i))));
					col.appendChild(lengthNode);

					structure.appendChild(col);
				}

				Element personList = d.createElement("CustomerData");
				cust.appendChild(personList);

				int j = 0;
				while(rs.next())
				{
					Element row = d.createElement("Person" + (++j));
					cust.appendChild(row);
					for(int i = 1; i <= columnCount; i++)
					{
						String colName = rsmd.getColumnName(i);
						Object value = rs.getObject(i);
						Element node = d.createElement(colName);
						node.appendChild(d.createTextNode((value != null) ? value.toString() : ""));
						row.appendChild(node);
					}
					personList.appendChild(row);
				}
				//Setting up Customer
				//Setting Up Department
				stmt = conn.prepareStatement("Select DEPTNO, DNAME, LOC From dept");
				rs = stmt.executeQuery();
				ResultSetMetaData rsmd1 = rs.getMetaData();

				int columnCount1 = rsmd1.getColumnCount();
				Element tableName1 = d.createElement("TableName");
				tableName1.appendChild(d.createTextNode(rsmd1.getTableName(1)));
				dept.appendChild(tableName1);

				Element structure1 = d.createElement("TableStructure");
				dept.appendChild(structure1);

				Element col1 = null;
				for(int i = 1; i <= columnCount1; i++)
				{
					col1 = d.createElement("Column" + 1);
					dept.appendChild(col1);
					Element colNode = d.createElement("ColumnName");
					colNode.appendChild(d.createTextNode(rsmd1.getColumnName(i)));
					col1.appendChild(colNode);

					Element typeNode = d.createElement("ColumnType");
					typeNode.appendChild(d.createTextNode(String.valueOf(rsmd1.getColumnTypeName(i))));
					col1.appendChild(typeNode);

					Element lengthNode = d.createElement("Length");
					lengthNode.appendChild(d.createTextNode(String.valueOf(rsmd1.getPrecision(i))));
					col1.appendChild(lengthNode);

					structure1.appendChild(col1);
				}

				Element personList1 = d.createElement("DepartmentData");
				dept.appendChild(personList1);

				int j1 = 0;
				while(rs.next())
				{
					Element row = d.createElement("Department" + (++j1));
					dept.appendChild(row);
					for(int i = 1; i <= columnCount1; i++)
					{
						String colName = rsmd1.getColumnName(i);
						Object value = rs.getObject(i);
						Element node = d.createElement(colName);
						node.appendChild(d.createTextNode((value != null) ? value.toString() : ""));
						row.appendChild(node);
					}
					personList1.appendChild(row);
				}
				//Setting Up Department
				//Setting Up Employee
				stmt = conn.prepareStatement("Select EMPNO, ENAME, JOB, MGR, SAL, COMM, DEPTNO From emp");
				rs = stmt.executeQuery();
				ResultSetMetaData rsmd2 = rs.getMetaData();

				int columnCount2 = rsmd2.getColumnCount();
				Element tableName2 = d.createElement("TableName");
				tableName2.appendChild(d.createTextNode(rsmd2.getTableName(1)));
				emp.appendChild(tableName2);

				Element structure2 = d.createElement("TableStructure");
				emp.appendChild(structure2);

				Element col2 = null;
				for(int i = 1; i <= columnCount2; i++)
				{
					col2 = d.createElement("Column" + 1);
					emp.appendChild(col2);
					Element colNode = d.createElement("ColumnName");
					colNode.appendChild(d.createTextNode(rsmd2.getColumnName(i)));
					col2.appendChild(colNode);

					Element typeNode = d.createElement("ColumnType");
					typeNode.appendChild(d.createTextNode(String.valueOf(rsmd2.getColumnTypeName(i))));
					col2.appendChild(typeNode);

					Element lengthNode = d.createElement("Length");
					lengthNode.appendChild(d.createTextNode(String.valueOf(rsmd2.getPrecision(i))));
					col2.appendChild(lengthNode);

					structure2.appendChild(col2);
				}

				Element personList2 = d.createElement("EmployeeData");
				emp.appendChild(personList2);

				int j2 = 0;
				while(rs.next())
				{
					Element row = d.createElement("Employee" + (++j2));
					emp.appendChild(row);
					for(int i = 1; i <= columnCount2; i++)
					{
						String colName = rsmd2.getColumnName(i);
						Object value = rs.getObject(i);
						Element node = d.createElement(colName);
						node.appendChild(d.createTextNode((value != null) ? value.toString() : ""));
						row.appendChild(node);
					}
					personList2.appendChild(row);
				}
				//Setting Up Employee
				//Setting Up Product
				stmt = conn.prepareStatement("Select PRODID, PRICE, MADE_BY, DESCRIP From product");
				rs = stmt.executeQuery();
				ResultSetMetaData rsmd3 = rs.getMetaData();

				int columnCount3 = rsmd3.getColumnCount();
				Element tableName3 = d.createElement("TableName");
				tableName3.appendChild(d.createTextNode(rsmd3.getTableName(1)));
				prod.appendChild(tableName3);

				Element structure3 = d.createElement("TableStructure");
				prod.appendChild(structure3);

				Element col3 = null;
				for(int i = 1; i <= columnCount3; i++)
				{
					col3 = d.createElement("Column" + 1);
					prod.appendChild(col3);
					Element colNode = d.createElement("ColumnName");
					colNode.appendChild(d.createTextNode(rsmd3.getColumnName(i)));
					col3.appendChild(colNode);

					Element typeNode = d.createElement("ColumnType");
					typeNode.appendChild(d.createTextNode(String.valueOf(rsmd3.getColumnTypeName(i))));
					col3.appendChild(typeNode);

					Element lengthNode = d.createElement("Length");
					lengthNode.appendChild(d.createTextNode(String.valueOf(rsmd3.getPrecision(i))));
					col3.appendChild(lengthNode);

					structure3.appendChild(col3);
				}

				Element personList3 = d.createElement("ProductData");
				prod.appendChild(personList3);

				int j3 = 0;
				while(rs.next())
				{
					Element row = d.createElement("Product" + (++j3));
					prod.appendChild(row);
					for(int i = 1; i <= columnCount3; i++)
					{
						String colName = rsmd3.getColumnName(i);
						Object value = rs.getObject(i);
						Element node = d.createElement(colName);
						node.appendChild(d.createTextNode((value != null) ? value.toString() : ""));
						row.appendChild(node);
					}
					personList3.appendChild(row);
				}
				//Setting Up Product
				dSource = new DOMSource(d);
				TransformerFactory tf = TransformerFactory.newInstance();
				Transformer t = tf.newTransformer();
				t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
				t.setOutputProperty(OutputKeys.METHOD, "xml");
				t.setOutputProperty(OutputKeys.ENCODING, "ISO-8859-1");

				StringWriter sw = new StringWriter();
				StreamResult sr = new StreamResult(sw);
				//t.transform(dSource, sr);
				//System.out.println("Xnl document 1" + sw.toString());
				FileOutputStream oStream = new FileOutputStream(new File(filename));
				t.transform(dSource, new StreamResult(oStream));
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			finally 
			{  
				try {
					if (rs != null)
						rs.close();
					if (stmt != null)
						stmt.close();
					if (conn != null)
						conn.close();
				}
				catch (SQLException se) {
					se.printStackTrace();
				}
			}
		}
		catch (Exception e)
		{
				e.printStackTrace();
		}
	}
}
