import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
ssssssssssssssssssssss

class ButtonListener implements ActionListener
{
	int count = 0;
	public void actionPerformed(ActionEvent e)
	{
	    //System.out.println("Button pressed (" + count++ + ") " + 
			       e.getActionCommand());
	}
}
sssssssssssssssssssssss
class ButtonCloser extends WindowAdapter
{
  //ooh  
}

public class ButtonFrame extends JFrame
{
	public ButtonFrame()
	{
		// aah
	}

	public static void main(String args[])
	{
		JFrame f = new ButtonFrame();
	}
	public void doNot()
	{

	}
}
