﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Assignment1
{
    public class Assignment1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        Matrix world = Matrix.Identity;
        Matrix view;
        Matrix projection;

        float angle = 0;
        float angle2 = 0;
        float distance = 20f;
        float cameraTranslationX = 0;
        float cameraTranslationY = 0;
        float lightRotateX = 0;
        float lightRotateY = 0;

        float defaultAngle = 0;
        float defaultAngle2 = 0;
        float defaultDistance = 20f;
        float defaultCameraTranslationX = 0;
        float defaultCameraTranslationY = 0;
        float defaultLightRotateX = 0;
        float defaultLightRotateY = 0;

        Effect effect;

        Model model;

        Vector4 ambientColor = new Vector4(0, 0, 0, 0);
        float ambientIntensity = 0.1f;
        Vector4 diffuseColor = new Vector4(1, 1, 1, 1);
        Vector3 lightPosition = new Vector3(1, 1, 1);
        float diffuseIntensity = 1.0f;

        float r = 1f;
        float g = 1f;
        float b = 1f;
        float i = 1f;

        SpriteFont font;
        MouseState previousMouseState;
        KeyboardState previousKeyState;

        Vector4 specularColor = new Vector4(1, 1, 1, 1);
        float specularIntensity = 1.0f;
        float shininess = 10.0f;
        Vector3 cameraPosition;
        int technique = 0;
        bool controlHelp = false;
        bool infoDisplay = false;
        string shaderType = "Gouraud";
        float lightIntensity = 1f;
        public Assignment1()
        {
            _graphics = new GraphicsDeviceManager(this);
            _graphics.GraphicsProfile = GraphicsProfile.HiDef;
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            model = Content.Load<Model>("Torus");
            effect = Content.Load<Effect>("SimpleShading");
            font = Content.Load<SpriteFont>("Font");
            world = Matrix.Identity;
            view = Matrix.CreateLookAt(
                new Vector3(0, 0, -5), // play around with this value
                new Vector3(),
                new Vector3(0, 1, 0)
                );
            projection = Matrix.CreatePerspectiveFieldOfView(
                MathHelper.ToRadians(90),
                GraphicsDevice.Viewport.AspectRatio,
                0.1f, 100
                );
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            MouseState currMouse = Mouse.GetState();
            if (currMouse.LeftButton == ButtonState.Pressed && previousMouseState.LeftButton == ButtonState.Pressed)
            {
                angle += (previousMouseState.X - currMouse.X) / 100f;
                angle2 += (previousMouseState.Y - currMouse.Y) / 100f;
            }
            if(Keyboard.GetState().IsKeyDown(Keys.Left))
            {
                lightRotateX += 0.02f;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.Right))
            {
                lightRotateX -= 0.02f;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.Up))
            {
                lightRotateY -= 0.02f;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.Down))
            {
                lightRotateY += 0.02f;
            }

            if(Keyboard.GetState().IsKeyDown(Keys.S))
            {
                angle = defaultAngle;
                angle2 = defaultAngle2;
                distance = defaultDistance;
                cameraTranslationX = defaultCameraTranslationX;
                cameraTranslationY = defaultCameraTranslationY;
                lightRotateX = defaultLightRotateX;
                lightRotateY = defaultLightRotateY;
                specularIntensity = 1f;
                ambientIntensity = 0.1f;
                diffuseIntensity = 1f;
                shininess = 10f;
                r = 1f;
                g = 1f;
                b = 1f;
                lightIntensity = 1f;
            }

            if(Keyboard.GetState().IsKeyDown(Keys.L) && !Keyboard.GetState().IsKeyDown(Keys.LeftShift))
            {
                r += 0.01f;
                g += 0.01f;
                b += 0.01f;
                lightIntensity += 0.01f;
            }
            if(Keyboard.GetState().IsKeyDown(Keys.LeftShift) && Keyboard.GetState().IsKeyDown(Keys.L))
            {
                r -= 0.01f;
                g -= 0.01f;
                b -= 0.01f;
                lightIntensity += 0.01f;
            }

            if(Keyboard.GetState().IsKeyDown(Keys.R) && !Keyboard.GetState().IsKeyDown(Keys.LeftShift))
            {
                r += 0.01f;
            }    
            if(Keyboard.GetState().IsKeyDown(Keys.R) && Keyboard.GetState().IsKeyDown(Keys.LeftShift))
            {
                r -= 0.01f;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.G) && !Keyboard.GetState().IsKeyDown(Keys.LeftShift))
            {
                g += 0.01f;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.G) && Keyboard.GetState().IsKeyDown(Keys.LeftShift))
            {
                g -= 0.01f;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.B) && !Keyboard.GetState().IsKeyDown(Keys.LeftShift))
            {
                b += 0.01f;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.B) && Keyboard.GetState().IsKeyDown(Keys.LeftShift))
            {
                b -= 0.01f;
            }

            if(Keyboard.GetState().IsKeyDown(Keys.OemPlus))
            {
                specularIntensity += 0.01f;
            }
            if(Keyboard.GetState().IsKeyDown(Keys.OemMinus))
            {
                specularIntensity -= 0.01f;
            }

            if(Keyboard.GetState().IsKeyDown(Keys.LeftControl) && Keyboard.GetState().IsKeyDown(Keys.OemPlus))
            {
                shininess += 0.01f;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.LeftControl) && Keyboard.GetState().IsKeyDown(Keys.OemMinus))
            {
                shininess -= 0.01f;
            }

            if (currMouse.RightButton == ButtonState.Pressed && previousMouseState.RightButton == ButtonState.Pressed)
            {
                distance += (previousMouseState.Y - currMouse.Y) / 100f;
            }

            if(currMouse.MiddleButton == ButtonState.Pressed && previousMouseState.MiddleButton == ButtonState.Pressed)
            {
                cameraTranslationX -= (previousMouseState.X - currMouse.X) / 100f;
                cameraTranslationY += (previousMouseState.Y - currMouse.Y) / 100f;
            }

            if (Keyboard.GetState().IsKeyDown(Keys.D1))
            {
                model = Content.Load<Model>("box");
            }
            if (Keyboard.GetState().IsKeyDown(Keys.D2))
            {
                model = Content.Load<Model>("sphere");
            }
            if (Keyboard.GetState().IsKeyDown(Keys.D3))
            {
                model = Content.Load<Model>("Torus");
            }
            if (Keyboard.GetState().IsKeyDown(Keys.D4))
            {
                model = Content.Load<Model>("teapot");
            }
            if (Keyboard.GetState().IsKeyDown(Keys.D5))
            {
                model = Content.Load<Model>("bunny");
            }

            if (Keyboard.GetState().IsKeyDown(Keys.F1))
            {
                technique = 0;
                shaderType = "Gouraud";
            }
            if (Keyboard.GetState().IsKeyDown(Keys.F2))
            {
                technique = 1;
                shaderType = "Phong";
            }
            if(Keyboard.GetState().IsKeyDown(Keys.F3))
            {
                technique = 2;
                shaderType = "PhongBlinn";
            }
            if(Keyboard.GetState().IsKeyDown(Keys.F4))
            {
                technique = 3;
                shaderType = "Schlick";
            }
            if(Keyboard.GetState().IsKeyDown(Keys.F5))
            {
                technique = 4;
                shaderType = "Toon";
            }
            if(Keyboard.GetState().IsKeyDown(Keys.F6))
            {
                technique = 5;
                shaderType = "HalfLife";
            }

            if(Keyboard.GetState().IsKeyDown(Keys.OemQuestion) && !previousKeyState.IsKeyDown(Keys.OemQuestion))
            {
                controlHelp = !controlHelp;
                infoDisplay = false;
            }

            if(Keyboard.GetState().IsKeyDown(Keys.H) && !previousKeyState.IsKeyDown(Keys.H))
            {
                infoDisplay = !infoDisplay;
                controlHelp = false;
            }
            /*Vector3 cameraPosition = Vector3.Transform(
                new Vector3(0, 0, distance),
                Matrix.CreateRotationX(angle2) * Matrix.CreateRotationY(angle));
            view = Matrix.CreateLookAt(
                cameraPosition,
                new Vector3(),
                new Vector3(0, 1, 0)
                );*/
            cameraPosition = Vector3.Transform(new Vector3(0, 0, distance),
                Matrix.CreateRotationX(angle2) * Matrix.CreateRotationY(angle));
            view = Matrix.CreateRotationY(angle) *
                Matrix.CreateRotationX(angle2) *
                Matrix.CreateTranslation(new Vector3(cameraTranslationX, cameraTranslationY, -distance));
            //lightPosition = new Vector3(lightRotateX, lightRotateY, 1);
            lightPosition = Vector3.Transform(new Vector3(1, 1, 1),
                Matrix.CreateRotationX(lightRotateY) * Matrix.CreateRotationY(lightRotateX));
            previousMouseState = Mouse.GetState();
            previousKeyState = Keyboard.GetState();
            diffuseColor = new Vector4(r, g, b, i);

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            GraphicsDevice.BlendState = BlendState.Opaque; 
            GraphicsDevice.DepthStencilState = new DepthStencilState();
            effect.CurrentTechnique = effect.Techniques[technique];
            foreach (EffectPass pass in effect.CurrentTechnique.Passes)
            {
                foreach (ModelMesh mesh in model.Meshes)
                {
                    foreach (ModelMeshPart part in mesh.MeshParts)
                    {
                        effect.Parameters["World"].SetValue(mesh.ParentBone.Transform);
                        effect.Parameters["View"].SetValue(view);
                        effect.Parameters["Projection"].SetValue(projection);
                        Matrix worldInverseTransposeMatrix = Matrix.Transpose(
                            Matrix.Invert(mesh.ParentBone.Transform));
                        effect.Parameters["WorldInverseTranspose"].SetValue(worldInverseTransposeMatrix);
                        effect.Parameters["AmbientColor"].SetValue(ambientColor);
                        effect.Parameters["AmbientIntensity"].SetValue(ambientIntensity);

                        //effect.Parameters["LightPosition"].SetValue(lightPosition);
                        effect.Parameters["DiffuseColor"].SetValue(diffuseColor);
                        effect.Parameters["DiffuseIntensity"].SetValue(diffuseIntensity);

                        effect.Parameters["LightPosition"].SetValue(lightPosition);
                        effect.Parameters["CameraPosition"].SetValue(cameraPosition);

                        effect.Parameters["SpecularColor"].SetValue(specularColor);
                        effect.Parameters["SpecularIntensity"].SetValue(specularIntensity);
                        effect.Parameters["Shininess"].SetValue(shininess);

                        pass.Apply();
                        GraphicsDevice.SetVertexBuffer(part.VertexBuffer);
                        GraphicsDevice.Indices = part.IndexBuffer;

                        GraphicsDevice.DrawIndexedPrimitives(
                        PrimitiveType.TriangleList,
                        part.VertexOffset,
                        part.StartIndex,
                        part.PrimitiveCount);
                    }
                }
            }
            base.Draw(gameTime);
            _spriteBatch.Begin();
            if (controlHelp)
            {
                _spriteBatch.DrawString(font, "Left Click and Drag to rotate Camera\nRight Click and Drag to change distance of Camera to center\nMiddle Click and Drag to Translate the Camera\nUse Arrow Keys to rotate the Light\nPress S to reset Light and Camera to default settings\nPress F1 for Gouraud Shading\nPress F2 for Phong Shading\nPress F3 for PhongBlinn Shading\nPress F4 for Schlick Shading\nPress F5 for Toon Shading\nPress F6 for HalfLife Shading\nPress L to increase Light Intensity (with Shift to decrease)\nPress the R, G, or B keys to increase the red, green, or blue values of light, respectively (with Shift to decrease)\nUse + or - to increase or decrease the Specular Intensity\nUse + or - with Left Control to increase or decrease the Shininess\nUse ? to show/hide key control info\nUse H to show/hide scene info", Vector2.UnitX + Vector2.UnitY * 5, Color.Black);
            }
            if (infoDisplay)
            {
                _spriteBatch.DrawString(font, "Camera angle X: " + angle + "\nCamera angle Y: " + angle2 + "\nLight angle X: " + lightRotateX + "\nLight angle Y: " + lightRotateY + "\nShader type: " + shaderType + "\nLight Intensity: " + lightIntensity + "\nSpecular intensity: " + specularIntensity + "\nR: " + r + "\nG: " + g + "\nB: " + b + "\nShininess: " + shininess, Vector2.UnitX + Vector2.UnitY * 5, Color.Black);
            }
            _spriteBatch.End();
        }
    }
}
