﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

using CPI411.SimpleEngine;
namespace SBRDF
{
    public class SBRDF : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        Matrix world = Matrix.Identity;
        Matrix view;
        Matrix projection;

        float angle = 0;
        float angle2 = 0;
        float distance = 20f;
        float cameraTranslationX = 0;
        float cameraTranslationY = 0;
        float lightRotateX = 0;
        float lightRotateY = 0;

        float defaultAngle = 0;
        float defaultAngle2 = 0;
        float defaultDistance = 20f;
        float defaultCameraTranslationX = 0;
        float defaultCameraTranslationY = 0;
        float defaultLightRotateX = 0;
        float defaultLightRotateY = 0;

        Effect effect;

        Model model;

        Vector4 ambientColor = new Vector4(0, 0, 0, 0);
        float ambientIntensity = 0.1f;
        Vector4 diffuseColor = new Vector4(1, 1, 1, 1);
        Vector3 lightPosition = new Vector3(0, 0, 20);
        float diffuseIntensity = 1.0f;

        float r = 1f;
        float g = 1f;
        float b = 1f;
        float i = 1f;
        float U = 1f;
        float V = 1f;
        float W = 1f;
        SpriteFont font;
        MouseState previousMouseState;
        KeyboardState previousKeyState;

        Vector4 specularColor = new Vector4(1, 1, 1, 1);
        float specularIntensity = 1.0f;
        float shininess = 10.0f;
        Vector3 cameraPosition;
        int technique = 0;
        bool controlHelp = false;
        bool infoDisplay = false;
        string shaderType = "1";
        float lightIntensity = 1f;
        float reflectivity = 0.50f;
        bool mipmap = false;
        bool selfShadow = false;
        bool normalizeTangent = true;
        bool normalizeNormalMap = true;
        Texture2D texture;
        Texture2D ramp;
        Skybox skybox; // *** Go to the References and add the SimpleEngine
        Matrix invertCamera;
        float x = 1;
        int modeltype = 1;

        public SBRDF()
        {
            _graphics = new GraphicsDeviceManager(this);
            _graphics.GraphicsProfile = GraphicsProfile.HiDef;
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            model = Content.Load<Model>("sphere");
            effect = Content.Load<Effect>("SBRDFShader");
            font = Content.Load<SpriteFont>("Font");
            texture = Content.Load<Texture2D>("crossHatch");
            ramp = Content.Load<Texture2D>("FinalProjectTexture");
            world = Matrix.Identity;
            /*view = Matrix.CreateLookAt(
                new Vector3(0, 0, -5), // play around with this value
                new Vector3(),
                new Vector3(0, 1, 0)
                );*/
            projection = Matrix.CreatePerspectiveFieldOfView(
            MathHelper.ToRadians(90), 800f / 600f, 0.01f, 1000f);
            string[] skyboxTextures =
                {
                    "nvlobby_new_negx", "nvlobby_new_posx",
                    "nvlobby_new_negy", "nvlobby_new_posy",
                    "nvlobby_new_negz", "nvlobby_new_posz"
                };
            skybox = new Skybox(skyboxTextures, Content, GraphicsDevice);
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            MouseState currMouse = Mouse.GetState();
            if (currMouse.LeftButton == ButtonState.Pressed && previousMouseState.LeftButton == ButtonState.Pressed)
            {
                angle += (previousMouseState.X - currMouse.X) / 100f;
                angle2 += (previousMouseState.Y - currMouse.Y) / 100f;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.Left))
            {
                lightRotateX += 0.02f;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.Right))
            {
                lightRotateX -= 0.02f;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.Up))
            {
                lightRotateY -= 0.02f;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.Down))
            {
                lightRotateY += 0.02f;
            }

            if (Keyboard.GetState().IsKeyDown(Keys.S))
            {
                angle = defaultAngle;
                angle2 = defaultAngle2;
                distance = defaultDistance;
                cameraTranslationX = defaultCameraTranslationX;
                cameraTranslationY = defaultCameraTranslationY;
                lightRotateX = defaultLightRotateX;
                lightRotateY = defaultLightRotateY;
                specularIntensity = 1f;
                ambientIntensity = 0.1f;
                diffuseIntensity = 1f;
                shininess = 10f;
                r = 1f;
                g = 1f;
                b = 1f;
                lightIntensity = 1f;
            }

            if (currMouse.RightButton == ButtonState.Pressed && previousMouseState.RightButton == ButtonState.Pressed)
            {
                distance += (previousMouseState.Y - currMouse.Y) / 100f;
            }

            if (currMouse.MiddleButton == ButtonState.Pressed && previousMouseState.MiddleButton == ButtonState.Pressed)
            {
                cameraTranslationX -= (previousMouseState.X - currMouse.X) / 100f;
                cameraTranslationY += (previousMouseState.Y - currMouse.Y) / 100f;
            }

            if (Keyboard.GetState().IsKeyDown(Keys.U) && !previousKeyState.IsKeyDown(Keys.LeftShift)/* && !previousKeyState.IsKeyDown(Keys.U)*/)
            {
                U += 0.01f;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.U) && previousKeyState.IsKeyDown(Keys.LeftShift)/* && !previousKeyState.IsKeyDown(Keys.U)*/)
            {
                U -= 0.01f;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.V) && !previousKeyState.IsKeyDown(Keys.LeftShift)/* && !previousKeyState.IsKeyDown(Keys.V)*/)
            {
                V += 0.01f;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.V) && previousKeyState.IsKeyDown(Keys.LeftShift) /*&& !previousKeyState.IsKeyDown(Keys.V)*/)
            {
                V -= 0.01f;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.W) && !previousKeyState.IsKeyDown(Keys.LeftShift)/* && !previousKeyState.IsKeyDown(Keys.W)*/)
            {
                W += 0.01f;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.W) && previousKeyState.IsKeyDown(Keys.LeftShift)/* && !previousKeyState.IsKeyDown(Keys.W)*/)
            {
                W -= 0.01f;
            }

            if (Keyboard.GetState().IsKeyDown(Keys.D1))
            {
                ramp = Content.Load<Texture2D>("FinalProjectTexture");
                x = 1;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.D2))
            {
                ramp = Content.Load<Texture2D>("FinalProjectTexture1");
                x = 2;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.D3))
            {
                ramp = Content.Load<Texture2D>("FinalProjectTexture2");
                x = 3;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.D4))
            {
                ramp = Content.Load<Texture2D>("FinalProjectTexture3");
                x = 4;
            }

            if (Keyboard.GetState().IsKeyDown(Keys.F1))
            {
                /*effect = Content.Load<Effect>("SBRDFShader");
                shaderType = "1";
                normalizeTangent = true;
                normalizeNormalMap = true;*/
                model = Content.Load<Model>("sphere");
                modeltype = 1;
            }

            if (Keyboard.GetState().IsKeyDown(Keys.F2))
            {
                /*effect = Content.Load<Effect>("SBRDFShader");
                shaderType = "1";
                normalizeTangent = true;
                normalizeNormalMap = true;*/
                model = Content.Load<Model>("Torus");
                modeltype = 2;
            }

            if (Keyboard.GetState().IsKeyDown(Keys.F3))
            {
                /*effect = Content.Load<Effect>("SBRDFShader");
                shaderType = "1";
                normalizeTangent = true;
                normalizeNormalMap = true;*/
                model = Content.Load<Model>("bunnyUV");
                modeltype = 3;
            }

            if (Keyboard.GetState().IsKeyDown(Keys.F4))
            {
                /*effect = Content.Load<Effect>("SBRDFShader");
                shaderType = "1";
                normalizeTangent = true;
                normalizeNormalMap = true;*/
                technique = 0;
            }

            if (Keyboard.GetState().IsKeyDown(Keys.F5))
            {
                /*effect = Content.Load<Effect>("SBRDFShader");
                shaderType = "1";
                normalizeTangent = true;
                normalizeNormalMap = true;*/
                technique = 1;
            }

            if (Keyboard.GetState().IsKeyDown(Keys.F6))
            {
                /*effect = Content.Load<Effect>("SBRDFShader");
                shaderType = "1";
                normalizeTangent = true;
                normalizeNormalMap = true;*/
                technique = 2;
            }

            if (Keyboard.GetState().IsKeyDown(Keys.F7))
            {
                /*effect = Content.Load<Effect>("SBRDFShader");
                shaderType = "1";
                normalizeTangent = true;
                normalizeNormalMap = true;*/
                technique = 3;
            }

            if (Keyboard.GetState().IsKeyDown(Keys.OemQuestion) && !previousKeyState.IsKeyDown(Keys.OemQuestion))
            {
                controlHelp = !controlHelp;
                infoDisplay = false;
            }

            if (Keyboard.GetState().IsKeyDown(Keys.H) && !previousKeyState.IsKeyDown(Keys.H))
            {
                infoDisplay = !infoDisplay;
                controlHelp = false;
            }
            /*cameraPosition = Vector3.Transform(new Vector3(0, 0, distance),
                Matrix.CreateRotationX(angle2) * Matrix.CreateRotationY(angle));*/
            cameraPosition = Vector3.Transform(Vector3.Zero,
                Matrix.CreateTranslation(new Vector3(0, 0, distance)) *
                Matrix.CreateRotationX(angle2) *
                Matrix.CreateRotationY(angle));
            view = Matrix.CreateRotationY(angle) *
                Matrix.CreateRotationX(angle2) *
                Matrix.CreateTranslation(new Vector3(cameraTranslationX, cameraTranslationY, -distance));
            //lightPosition = new Vector3(lightRotateX, lightRotateY, 1);
            lightPosition = Vector3.Transform(new Vector3(0, 0, 10),
                Matrix.CreateRotationX(lightRotateY) * Matrix.CreateRotationY(lightRotateX));
            previousMouseState = Mouse.GetState();
            previousKeyState = Keyboard.GetState();
            diffuseColor = new Vector4(r, g, b, i);
            //responsible for rotating mesh to face the camera.
            //invertCamera = Matrix.CreateRotationY(angle) * Matrix.CreateRotationX(angle2);
            //x += 0.01f;
            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            GraphicsDevice.BlendState = BlendState.Opaque;
            GraphicsDevice.DepthStencilState = new DepthStencilState();
            RasterizerState originalRasterizerState = _graphics.GraphicsDevice.RasterizerState;
            RasterizerState rasterizerState = new RasterizerState();
            rasterizerState.CullMode = CullMode.CullClockwiseFace;
            _graphics.GraphicsDevice.RasterizerState = rasterizerState;
            if (skybox != null)
            {
                skybox.Draw(view, projection, cameraPosition);
            }

            _graphics.GraphicsDevice.RasterizerState = originalRasterizerState;
            effect.CurrentTechnique = effect.Techniques[technique];
            foreach (EffectPass pass in effect.CurrentTechnique.Passes)
            {
                foreach (ModelMesh mesh in model.Meshes)
                {
                    foreach (ModelMeshPart part in mesh.MeshParts)
                    {
                        //effect.Parameters["bumpHeight"].SetValue(W);
                        //if (mipmap)
                        //    effect.Parameters["mipmap"].SetValue(1);
                        //else if (!mipmap)
                        //    effect.Parameters["mipmap"].SetValue(0);
                        effect.Parameters["World"].SetValue(mesh.ParentBone.Transform /** Matrix.CreateRotationX(1.4f)*/ /** Matrix.CreateRotationY(angle)*/);
                        effect.Parameters["View"].SetValue(view);
                        effect.Parameters["Projection"].SetValue(projection);
                        Matrix worldInverseTranspose =
                            Matrix.Transpose(Matrix.Invert(mesh.ParentBone.Transform));
                        effect.Parameters["WorldInverseTranspose"].SetValue(worldInverseTranspose);
                        effect.Parameters["CameraPosition"].SetValue(cameraPosition);
                        effect.Parameters["LightPosition"].SetValue(lightPosition);
                        //effect.Parameters["T"].SetValue(texture);
                        effect.Parameters["DiffuseColor"].SetValue(new Vector4(1, 1, 1, 1));
                        effect.Parameters["DiffuseIntensity"].SetValue(1.0f);
                        effect.Parameters["SpecularColor"].SetValue(new Vector4(1, 1, 1, 1));
                        effect.Parameters["SpecularIntensity"].SetValue(1.0f);
                        effect.Parameters["Shininess"].SetValue(20f);
                        //effect.Parameters["T"].SetValue(texture);
                        effect.Parameters["Ramp"].SetValue(ramp);
                        //effect.Parameters["T"].SetValue(texture);
                        //effect.Parameters["parametric"].SetValue(new Vector2(U, V));
                        pass.Apply();
                        GraphicsDevice.SetVertexBuffer(part.VertexBuffer);
                        GraphicsDevice.Indices = part.IndexBuffer;
                        GraphicsDevice.DrawIndexedPrimitives(
                        PrimitiveType.TriangleList, part.VertexOffset, part.StartIndex, part.PrimitiveCount);
                    }
                }
            }
            //DrawModelWithEffect();
            base.Draw(gameTime);
            _spriteBatch.Begin();
            if (controlHelp)
            {
                _spriteBatch.DrawString(font, "\nLeft Click and Drag to rotate Camera\nRight Click and Drag to change distance of Camera to center\nMiddle Click and Drag to Translate the Camera\nUse Arrow Keys to rotate the Light\nPress S to reset Light and Camera to default settings\nPress 1 to display BRDF with Texture 1\nPress 2 to display BRDF with Texture 2\nPress 3 to display BRDF with Texture 3\nPress4 to display BRDF with Texture 4\nUse F1 - F3 to change models\nUse F4 - F7 to change shaders\nUse ? to show/hide key control info\nUse H to show/hide scene info", Vector2.UnitX + Vector2.UnitY * 5, Color.AliceBlue);
            }
            if (infoDisplay)
            {
                _spriteBatch.DrawString(font, "Shader Mode: " + technique + "\nSelected Model: " + modeltype + "\nSelected Image: " + x + "\nLight angle X: " + lightRotateX + "\nLight angle Y: " + lightRotateY, Vector2.UnitX + Vector2.UnitY * 5, Color.AliceBlue);
            }
            _spriteBatch.End();
        }
    }
}
