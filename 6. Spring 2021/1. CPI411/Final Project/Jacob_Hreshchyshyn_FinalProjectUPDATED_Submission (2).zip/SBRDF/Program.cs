﻿using System;

namespace SBRDF
{
    public static class Program
    {
        [STAThread]
        static void Main()
        {
            using (var game = new SBRDF())
                game.Run();
        }
    }
}
