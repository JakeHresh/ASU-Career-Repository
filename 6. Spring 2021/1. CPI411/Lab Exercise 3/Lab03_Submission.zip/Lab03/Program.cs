﻿using System;

namespace Lab03
{
    public static class Program
    {
        [STAThread]
        static void Main()
        {
            using (var game = new Lab03())
                game.Run();
        }
    }
}
