﻿using System;

namespace Lab02
{
    public static class Program
    {
        [STAThread]
        static void Main()
        {
            using (var game = new Lab02())
                game.Run();
        }
    }
}
