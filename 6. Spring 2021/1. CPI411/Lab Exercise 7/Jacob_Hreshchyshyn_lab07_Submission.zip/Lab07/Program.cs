﻿using System;

namespace Lab07
{
    public static class Program
    {
        [STAThread]
        static void Main()
        {
            using (var game = new Lab07())
                game.Run();
        }
    }
}
