The Lab1 folder contains task2.js and task2test.js. When running the programs using node, you may load either file in whatever order.

task2test.js contains the following test functions that you may run:

invalidTournamentConstruction()

Attempts to create a tournament object using a badly formatted JSON string. Fails with an exception, which is error handled.

constructTournament()

Creates a tournament using a well formatted JSON string.

constructTournamentNoPlayers()

Creates a tournament object using a JSON string lacking player entities. Tests the function if that case is handled.

constructTournamentBadValues()

Creates a tournament object using values not intended, e.g. the string "xxx" for the par of the tournament.

postNonNumericScore()

Attempts to post a non-numeric score for a player where a number is expected. Value should still be accepted.

postNumericScore()

Posts numeric score as normal.

cannotGetWinner()

Attempts to get the winner of a tournament before checking if tournament is completed. Expected to fail.

canGetWinner()

Gets winner of a tournament after checking if tournament is completed. Expected to succeed.

tournamentNotCompleted()

Checks if unfinished tournament is completed. Expected not to be completed.

tournamentComplete()

Checks if tournament is completed. Expected to be completed.

testProjectByIndividual()

Checks if correct value is returned when projecting score by individual on individual player.

testProjectByHole()

Checks if correct value is returned when projecting score by hole on individual player.




Most edge cases are checked implicitly in these tests. For example, the case of selecting a winner in the instance where all players have the same score is
tested in canGetWinner(). Because all players have the same score and the first player in the list is Montgomerie, the test predicts that Montgomerie will be
set as the winner.

My inputs are appropriate because they work to test valid and invalid inputs for the purpose of determining how these functions handle such data. This especially
leads into the justification that negative and positive testing occurs since some tests anticipate bad input, which indicates an awareness to defend against
bad data.