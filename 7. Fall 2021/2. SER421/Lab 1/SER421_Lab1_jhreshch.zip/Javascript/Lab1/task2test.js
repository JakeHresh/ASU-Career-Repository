var testjson1 = '{"tournament":{"name":"British Open","year":2001,"award":840000,"yardage":6905,"par":71,"round":4,"players":[{"lastname":"Montgomerie","firstinitial":"C","score":0,"hole":0},{"lastname":"Fulke","firstinitial":"P","score":0,"hole":0},{"lastname":"Owen","firstinitial":"G","score":0,"hole":0},{"lastname":"Parnevik","firstinitial":"J","score":0,"hole":0},{"lastname":"Ogilvie","firstinitial":"J","score":0,"hole":0},{"lastname":"Cejka","firstinitial":"A","score":0,"hole":0},{"lastname":"Romero","firstinitial":"E","score":-1,"hole":"finished"},{"lastname":"Fasth","firstinitial":"N","score":0,"hole":0}]}}';
var test2json = '{"tournament":{"name":"British Open","year":2001,"award":840000,"yardage":6905,"par":71,"players":[{"lastname":"Montgomerie","firstinitial":"C","score":1,"hole":12},{"lastname":"Fulke","firstinitial":"P","score":-2,"hole":3},{"lastname":"Owen","firstinitial":"G","score":-1,"hole":7},{"lastname":"Parnevik","firstinitial":"J","score":-3,"hole":"finished"},{"lastname":"Ogilvie","firstinitial":"J","score":1,"hole":"finished"},{"lastname":"Cejka","firstinitial":"A","score":-2,"hole":9},{"lastname":"Romero","firstinitial":"E","score":0,"hole":"finished"},{"lastname":"Fasth","firstinitial":"N","score":-4,"hole":16}]}}';
var badjson = "sfs";
var testjsonnoplayer = '{"tournament":{"name":"British Open","year":2001,"award":840000,"yardage":6905,"par":71,"round":4,"players":[]}}';
var testjsonbadvalues = '{"tournament":{"name":"xxx","year":"xxx","award":"xxx","yardage":"xxx","par":"xxx","round":"xxx","players":[]}}';
var allwinners = '{"tournament":{"name":"British Open","year":2001,"award":840000,"yardage":6905,"par":71,"round":4,"players":[{"lastname":"Montgomerie","firstinitial":"C","score":0,"hole":"finished"},{"lastname":"Fulke","firstinitial":"P","score":0,"hole":"finished"},{"lastname":"Owen","firstinitial":"G","score":0,"hole":"finished"},{"lastname":"Parnevik","firstinitial":"J","score":0,"hole":"finished"},{"lastname":"Ogilvie","firstinitial":"J","score":0,"hole":"finished"},{"lastname":"Cejka","firstinitial":"A","score":0,"hole":"finished"},{"lastname":"Romero","firstinitial":"E","score":0,"hole":"finished"},{"lastname":"Fasth","firstinitial":"N","score":0,"hole":"finished"}]}}';
// Tests Tournament constructor by feeding it bad data. Should produce an exception. 
// Through negative testing, demonstrates that exception handling within the function is needed to handle bad data.
// This test also serves to test the parsetarget function, responsible for interpreting the JSON data.
function invalidTournamentConstruction() {
	try {
		let t = new Tournament(badjson);
	}
	catch(e) {
		console.log("Can't construct object with provided JSON");
	}
}

// Should produce tournament object correctly. Contains normal inputs.
function constructTournament() {
	let t = new Tournament(testjson1);
	if(t !== null) {
		console.log("Tournament constructed correctly");
		console.log(t);
	}
}

// Should produce tournament object despite having no players.
function constructTournamentNoPlayers() {
	let t = new Tournament(testjsonnoplayer);
	if(t !== null) {
		console.log("Tournament constructed correctly");
		console.log(t);
	}
}

// Should produce tournament object despite having invalid values.
function constructTournamentBadValues() {
	let t = new Tournament(testjsonbadvalues);
	if(t !== null) {
		console.log("Tournament constructed correctly");
		console.log(t);
	}
}

// Should post non-numeric score for player
function postNonNumericScore() {
	let t = new Tournament(testjson1);
	t.players[0].postScore("Wonton is actually 1 tonne");
	if(t.players[0].score === "0Wonton is actually 1 tonne") {
		console.log("Score posted correctly");
		console.log(t.players[0].score);
	}
}

// Should post numeric score for player
function postNumericScore() {
	let t = new Tournament(testjson1);
	t.players[0].postScore(1);
	if(t.players[0].score === 1) {
		console.log("Score posted correctly");
		console.log(t.players[0].score);
	}
}

// Should not have getWinner() function
function cannotGetWinner() {
	let t = new Tournament(allwinners);
	try {
		t.getWinner();
	}
	catch(e) {
		console.log("Couldn't get winner");
	}
}

// Should have getWinner() function
function canGetWinner() {
	let t = new Tournament(allwinners);
	t.isTournamentCompleted();
	console.log("Could get winner");
	console.log(t.getWinner());
}

// Tests if tournament is completed on unfinished tournament
function tournamentNotCompleted() {
	let t = new Tournament(testjson1);
	if(!t.isTournamentCompleted()) {
		console.log("Tournament is not complete");
	}
}

// Tests is tournament is completed on finished tournament
function tournamentComplete() {
	let t = new Tournament(allwinners);
	if(t.isTournamentCompleted()) {
		console.log("Tournament is complete");
	}
}

// Tests accuracy of projectByIndividual
function testProjectByIndividual() {
	let t = new Tournament(test2json);
	if(projectScoreByIndividual(t, "Fulke", "P") === -12) {
		console.log("projectScoreByIndividual is accurate");
	}
}

// Tests accuracy of projectByHole
function testProjectByHole() {
	let t = new Tournament(test2json);
	if(projectScoreByHole(t, "Fulke", "P") === -3) {
		console.log("projectScoreByHole is accurate");
	}
}