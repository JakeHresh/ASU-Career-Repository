"use strict";

class Tournament {
	constructor(tournamentInfo) {
		this.name = parseTarget(tournamentInfo, "name");
		this.year = parseTarget(tournamentInfo, "year");
		this.award = parseTarget(tournamentInfo, "award");
		this.yardage = parseTarget(tournamentInfo, "yardage");
		this.par = parseTarget(tournamentInfo, "par");
		this.players = parseTarget(tournamentInfo, "players");
		Tournament.prototype.printLeaderboard = function() {
			let playerString = "";
			if(arguments[0] === projectScoreByIndividual) {
				playerString = this.projectedLeaderboard(projectScoreByIndividual);
			}
			else if(arguments[0] === projectScoreByHole) {
				playerString = this.projectedLeaderboard(projectScoreByHole);
			} 
			else {
				playerString = this.leaderboard();
			}
			const obj = JSON.parse(playerString);
			console.log("LEADERBOARD\n");
			for(let i = 0; i < obj.length; i++) {
				console.log(obj[i].firstinitial + ". " + obj[i].lastname + " -- Score: " + obj[i].score + " -- Hole: " + obj[i].hole + "\n");
			}
		}
	}

	leaderboard() {
		let sortedPlayers = [];
		for(let i = 0; i < this.players.length; i++) {
			sortedPlayers.push(this.players[i]);
		}
		//assign a number value to "finished", sort by that, and replace the number value with finished again
		for(let i = 0; i < sortedPlayers.length; i++) {
			if(sortedPlayers[i].hole === "finished") {
				sortedPlayers[i].hole = 18;
			}
		}
		// sorting referenced here:
		// https://flaviocopes.com/how-to-sort-array-of-objects-by-property-javascript/
		sortedPlayers.sort((a, b) => (a.score > b.score) ? 1 : (a.score === b.score) ? ((a.hole < b.hole) ? 1 : -1) : -1 );

		for(let i = 0; i < sortedPlayers.length; i++) {
			if(sortedPlayers[i].hole === 18) {
				sortedPlayers[i].hole = "finished";
			}
		}
		return JSON.stringify(sortedPlayers);
	}

	projectedLeaderboard(projectionFunction) {
		let sortedPlayers = [];
		let originalPlayers = [];
		let originalScores = [];
		for(let i = 0; i < this.players.length; i++) {
			sortedPlayers.push(this.players[i]);
			originalPlayers.push(this.players[i]);
			originalScores.push(this.players[i].score);
		}
		for(let i = 0; i < this.players.length; i++) {
			sortedPlayers[i].score = projectionFunction(this, sortedPlayers[i].lastname, sortedPlayers[i].firstinitial);
		}
		//assign a number value to "finished", sort by that, and replace the number value with finished again
		for(let i = 0; i < sortedPlayers.length; i++) {
			if(sortedPlayers[i].hole === "finished") {
				sortedPlayers[i].hole = 18;
			}
		}
		// sorting referenced here:
		// https://flaviocopes.com/how-to-sort-array-of-objects-by-property-javascript/
		sortedPlayers.sort((a, b) => (a.score > b.score) ? 1 : (a.score === b.score) ? ((a.hole < b.hole) ? 1 : -1) : -1 );

		for(let i = 0; i < sortedPlayers.length; i++) {
			if(sortedPlayers[i].hole === 18) {
				sortedPlayers[i].hole = "finished";
			}
		}
		let stringPlayers = JSON.stringify(sortedPlayers);
		for(let i = 0; i < sortedPlayers.length; i++) {
			originalPlayers[i].score = originalScores[i];
		}
		return stringPlayers;
	}

	isTournamentCompleted() {
		let completed = true;
		let player = this.players[0];
		for(let i = 0; i < this.players.length; i++) {
			if(this.players[i].score < player.score) {
				player = this.players[i];
			}
			if(this.players[i].hole !== "finished") {
				completed = false;
				i = this.players.length;
			}
		}
		if(completed) {
			this.winner = player;
			this.getWinner = function() {
				if(this.winner !== null) {
					return [this.winner.lastname, this.winner.score];
				}
			}
		}
		return completed;
	}
}

class Player {
	constructor(lname, finitial, s, h) {
		this.lastname = lname;
		this.firstinitial = finitial;
		this.score = s;
		this.hole = h;
	}

	postScore(score) {
		if(this.hole !== "finished") {
			this.score += score;
			this.hole++;
			if(this.hole === 18) {
				this.hole = "finished";
			}
		}
	}
}

function parseTarget(tournamentInfo, selection) {
	const obj = JSON.parse(tournamentInfo);
	//console.log(JSON.parse(obj.tournament.players));
	if (selection === "name") {
		return obj.tournament.name;
	}
	else if (selection === "year") {
		return obj.tournament.year;
	}
	else if (selection === "award") {
		return obj.tournament.award;
	}
	else if (selection === "yardage") {
		return obj.tournament.yardage;
	}
	else if (selection === "par") {
		return obj.tournament.par;
	}
	else if (selection === "players") {
		let players = [];
		// mapping referenced here:
		// https://stackoverflow.com/questions/42538582/getting-a-specific-value-from-json-array-with-multiple-arrays-inside-in-javascri
		let lastnames = obj.tournament.players.map(function(player) {
			return player.lastname;
		});
		let firstinitials = obj.tournament.players.map(function(player) {
			return player.firstinitial;
		});
		let scores = obj.tournament.players.map(function(player) {
			return player.score;
		});
		let holes = obj.tournament.players.map(function(player) {
			return player.hole;
		});
		let count = 0;
		for(let p in obj.tournament.players) {
			//var pl = JSON.parse(p);
			players.push(new Player(lastnames[count], firstinitials[count], scores[count], holes[count]));
			count++;
		}
		return players;
	}
}

function projectScoreByIndividual(tournament, lastname, firstinitial) {
	//***THESE ARE ONLY SHALLOW COPIES. MAKE THESE DEEP COPIES
	let lastnames_c = [];
	let firstinitials_c = [];
	let scores_c = [];
	let holes_c = [];
	let lastnames = tournament.players.map(function(player) {
		return player.lastname;
	});
	let firstinitials = tournament.players.map(function(player) {
		return player.firstinitial;
	});
	let scores = tournament.players.map(function(player) {
		return player.score;
	});
	let holes = tournament.players.map(function(player) {
		return player.hole;
	});
	for(let i = 0; i < lastnames.length; i++) {
		lastnames_c.push(lastnames[i]);
		firstinitials_c.push(firstinitials[i]);
		scores_c.push(scores[i]);
		holes_c.push(holes[i]);
	}
	for(let i = 0; i < lastnames.length; i++) {
		if(lastnames_c[i] === lastname && firstinitials_c[i] === firstinitial) {
			if(holes_c[i] === "finished") {
				return scores_c[i];
			}
			return Math.round((1/(holes_c[i]/18)) * scores_c[i]);
		}
	}
	console.log("Player not found");
}

function projectScoreByHole(tournament, lastname, firstinitial) {
	let foundPlayer = false;
	let scoresPerHole = [];
	let average = 0;
	let playerScore = 0;
	let playerHole = 0;
	//***THESE ARE ONLY SHALLOW COPIES. MAKE THESE DEEP COPIES
	let lastnames_c = [];
	let firstinitials_c = [];
	let scores_c = [];
	let holes_c = [];
	let lastnames = tournament.players.map(function(player) {
		return player.lastname;
	});
	let firstinitials = tournament.players.map(function(player) {
		return player.firstinitial;
	});
	let scores = tournament.players.map(function(player) {
		return player.score;
	});
	let holes = tournament.players.map(function(player) {
		return player.hole;
	});
	for(let i = 0; i < lastnames.length; i++) {
		if(lastnames[i] === lastname && firstinitials[i] === firstinitial) {
			foundPlayer = true;
			if(holes[i] === "finished") {
				return scores[i];
			}
			playerScore = scores[i];
			playerHole = holes[i];
		}
		else {
			if(holes[i] === "finished") {
				holes[i] = 18;
			}
			scoresPerHole.push(scores[i]/holes[i]);
			if(holes[i] === 18) {
				holes[i] = "finished";
			}
		}
	}
	if(!foundPlayer) {
		console.log("Player not found");
	}
	else {
		for(let i = 0; i < scoresPerHole.length; i++) {
			average += scoresPerHole[i];
		}
		average = average/lastnames.length;
		return Math.round(playerScore + average * (18 - playerHole));
	}
}