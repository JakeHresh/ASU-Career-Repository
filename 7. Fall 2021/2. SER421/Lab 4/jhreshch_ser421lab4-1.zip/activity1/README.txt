When testing the first five queries for this activity, I suggest you use the provided complete download of the
bing website since this is simply printing output of the elements and code found on the site. 

The last command does not apply for this local version of the site since, for whatever reason, the Bing logo
and text do not appear by default. To test the last query, go to the actual Bing website while searching
with the values provided and run that query. That should make it work properly.

Needless to say, for these queries and commands to function, the grader must copy and paste each query and
command in the browser's console to see the output.

The complete site is called dog phantom rocket - Bing.html. The modified source can be seen in activity.html 
(though only the logo should be modified). activity1.js contains the DOM commands and queries.