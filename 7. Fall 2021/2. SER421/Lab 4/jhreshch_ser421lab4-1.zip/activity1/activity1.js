
/*
	This DOM expression gets the <ol> element encompassing the results
	of the search. One could have used the ID of the ol to get the results
	ol as well. However, the results ol happens to be the first in the
	collection of ol's, making this valid.
*/
console.log(document.getElementsByTagName("ol")[0]);
/*
	This DOM expression gets the code for the body element's onload event.
	Because there are several body elements, I decided to search for the
	body element that is a member of the specified class. If you were to
	search the document, you will find that the only instance of this class
	name is with a body element described after a head element.
*/
console.log(document.getElementsByClassName("b_respl b_sbText")[0].onload);
// The below is a more concise version of the above.
console.log(document.body.onload);
/*
	This DOM expression gets the second child node under the body element. 
*/
console.log(document.body.childNodes[1]);
/*
	This DOM expression gets the number of h2 elements from the document.
*/
console.log(document.getElementsByTagName("h2").length);
/*
	This DOM expression gets the values of the search field. There is
	only one element whose class is b_searchbox.
*/
console.log(document.getElementsByClassName("b_searchbox")[0].value);
/*
	For whatever reason, when I save the webpage, the Bing logo and text
	are already gone. This is likely something to do with image files not
	being found on the local download of the site. However, because this
	logo is contained in this particular element, setting the style display
	to none should suffice to make the logo and text "go away". In any
	case, testing on the actual site in my browser demonstrates this working.
*/
document.getElementsByClassName("b_logo")[0].style.display="none"