Refer to the README in the activity1 subdirectory for more information on the queries
and website download.

When adding to the JSON dictionary for Activity 2 and Activity 3, be sure to provide
the exact same JSON format as that of the additional.json file used as an example for
this lab. You can copy all the code from that example when testing the expansion of
the Eliza dictionary.

For Activity 3, answers only repeat after each of the answers within an entry is already
used. However, when this happens, the session storage clears all responses, meaning that,
while duplicates do not appear until all entries within a section are displayed in sequence,
it is possible for another section to use up its duplicate reserve and cause duplicates
in another entry section to readily appear. However, this still meets the requirements
since no answer within an entry section is repeated until all answers within a section
are given at least once.

To test Activity 2 and 3, unzip their zip files, access the folder inside, and open
the html file in Chrome.