To run, use nodemon index.js. This command runs the server on localhost 8000

Ran npm i express.

Ran npm i joi.

Ran npm i -g nodemon.

API Elements

POST /tournaments - Satisfies API requirement 1
Requires JSON of tournament to be added in the body of the request. 
An example JSON might be the following:
{
    "name": "TEST6",
    "year": 2000,
    "award": 840000,
    "yardage": 6905,
    "par": 71,
    "players": [{
        "lastname":"sdfsf",
        "firstinitial":"X",
        "score":-3,
        "hole":17
    },
    {
       "lastname":"Montgomerie",
        "firstinitial":"Z",
        "score":-3,
        "hole":"finished" 
    }]
}
If creating a tournament without players, you must include the players
attribute as an empty list.

GET /tournaments - Satisfies API requirements 5 and 7
Retrieves the metadata of a tournament without including players.
You can provide query parameters lb and ub, which represent the lower
and upper bounds of the years you filter the tournaments by. If the
lb and ub data is invalid, it returns all tournaments as normal.

GET /players/:id - Satisfies API requirement 6
Retrieves all players in a given tournament. When using this,
replace :id with the name of the tournament you're searching for.
Be sure to replace spaces with %20.

POST /players - Satsifies API requirement 9
Creates a player that such that it exists separately from a tournament.
Requires JSON of player to be added in the body of the request.
An example JSON might be the following:
{
    "lastname":"Fast",
    "firstinitial":"N",
    "score":4,
    "hole":18
}

POST /tournaments/player/:id - Satisfies API requirement 2
Takes an existing player and adds it to a tournament.
On execution of the request, it ensures that the Player does
not already exist on an uncompleted Tournament. It also avoids
updating a completed Tournament. 
When using this command, replace :id with the name of the
tournament.
Additionally, provide a JSON of the player.
An example JSON might be the following:
{
    "lastname":"Fast",
    "firstinitial":"N",
    "score":4,
    "hole":18
}

DELETE /tournaments/player/:id - Satisfies API requirement 3
Deletes an existing player from an existing tournament.
On execution of the request, it ensures that the Player
already exists on an uncompleted tournament. It also avoids
updating a completed Tournament.
When using this command, replace :id with the name of the
tournament.
Additionally, provide a JSON of the player.
An example JSON might be the following:
{
    "lastname":"Fast",
    "firstinitial":"N",
    "score":4,
    "hole":18
}

PATCH /tournaments/player/:id - Satisfies API requirement 11
Performs a partial update on a player resource through a PATCH.
When using this command, replace :id with the name of the
tournament.
Additionally, provide a JSON of the player.
An example JSON might be the following:
{
    "lastname":"Fast",
    "firstinitial":"N",
    "score":4,
    "hole":18
}