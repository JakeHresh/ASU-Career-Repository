const Joi = require('joi');

const tournamentSchema = {
    name: Joi.string().min(1).required(),
    year: Joi.number(),
    award: Joi.number(),
    yardage: Joi.number(),
    par: Joi.number(),
    players: Joi.array()
}

const schema = Joi.object(tournamentSchema);

exports.validateTournament = (tournament) => schema.validate(tournament);