const Joi = require('joi');

const playerSchema = {
    lastname: Joi.string().min(1).required(),
    firstinitial: Joi.string().min(1).max(1).required(),
    score: Joi.number(),
    hole: Joi.number()
}

const schema = Joi.object(playerSchema);
exports.validatePlayer = (player) => schema.validate(player);