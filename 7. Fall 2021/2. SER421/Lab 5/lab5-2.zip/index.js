const express = require('express');
const bodyParser = require('body-parser');
const url = require('url');
const queryString = require('querystring');
const app = express();
const fs = require('fs');
const tournUtils = require('./utils/tournament-schema.js');
const playerUtils = require('./utils/player-schema.js');
const { response } = require('express');
var rawTournaments = fs.readFileSync('persistentStore.json');
var rawPlayers = fs.readFileSync('persistentStorePlayers.json');
var tournaments = JSON.parse(rawTournaments);
var players = JSON.parse(rawPlayers);

app.use(express.json());

// POST Player in tournament
app.post('/tournaments/player/:id', (request, response) => {
    const { error } = playerUtils.validatePlayer(request.body);
    if(error) {
        response.setHeader('Access-Control-Allow-Origin', '*');
        return response.status(400).send('The player must have a non-empty last name and a first initial no longer than 1 character.');
    }
    const player = {
        lastname: request.body.lastname,
        firstinitial: request.body.firstinitial,
        score: 0,
        hole: 0
    }
    let searchedPlayer = undefined;
    for(let i = 0; i < players['players'].length; i++) {
        if(players['players'][i].lastname == player.lastname && players['players'][i].firstinitial == player.firstinitial) {
            searchedPlayer = players['players'][i];
        }
    }
    if(searchedPlayer != undefined) {
        const tournamentName = request.params.id;
        let foundTournament = false;
        let t = undefined;
        for(let i = 0; i < tournaments['tournaments'].length; i++) {
            if(tournaments['tournaments'][i].name == tournamentName) {
                t = tournaments['tournaments'][i];
                foundTournament = true;
                break;
            }
        }
        if(!foundTournament) {
            response.setHeader('Access-Control-Allow-Origin', '*');
            return response.status(404).send('The specified tournament was not found.');
        }
        let completed = true;
        for(let i = 0; i < t.players.length; i++) {
            if(t.players[i].hole < 18) {
                completed = false;
                i = t.players.length;
            }
        }
        if(completed) {
            response.setHeader('Access-Control-Allow-Origin', '*');
            return response.status(405).send('The tournament is completed. You are not allowed to modify this resource.');
        }
        for(let i = 0; i < tournaments['tournaments'].length; i++) {
            for(let j = 0; j < tournaments['tournaments'][i].players.length; j++) {
                if(tournaments['tournaments'][i].players[j].lastname == searchedPlayer.lastname && tournaments['tournaments'][i].players[j].firstinitial == searchedPlayer.firstinitial) {
                    // Check if examined tournament is complete
                    let complete = true;
                    for(let m = 0; m < tournaments['tournaments'][i].players.length; m++) {
                        if(tournaments['tournaments'][i].players[m].hole < 18) {
                            complete = false;
                            m = tournaments['tournaments'][i].players.length
                        }
                    }
                    if(!complete) {
                        response.setHeader('Access-Control-Allow-Origin', '*');
                        return response.status(409).send('A Player of that name already exists.');
                    }
                }
            }
        }
        t.players.push(searchedPlayer);
        rawTournaments = JSON.stringify(tournaments);
        fs.writeFileSync('persistentStore.json', rawTournaments);
        response.setHeader('Access-Control-Allow-Origin', '*');
        return response.status(201).send(t);
    }
    else {
        response.setHeader('Access-Control-Allow-Origin', '*');
        return response.status(404).send('Player not found.');
    }
})

// DELETE Player in tournament
app.delete('/tournaments/player/:id', (request, response) => {
    const { error } = playerUtils.validatePlayer(request.body);
    if(error) {
        response.setHeader('Access-Control-Allow-Origin', '*');
        return response.status(400).send('The player must have a non-empty last name and a first initial no longer than 1 character.');
    }
    const player = {
        lastname: request.body.lastname,
        firstinitial: request.body.firstinitial,
        score: 0,
        hole: 0
    }
    const tournamentName = request.params.id;
    let foundTournament = false;
    let t = undefined;
    for(let i = 0; i < tournaments['tournaments'].length; i++) {
        if(tournaments['tournaments'][i].name == tournamentName) {
            t = tournaments['tournaments'][i];
            foundTournament = true;
            break;
        }
    }
    if(!foundTournament) {
        response.setHeader('Access-Control-Allow-Origin', '*');
        return response.status(404).send('The specified tournament was not found.');
    }
    let completed = true;
        for(let i = 0; i < t.players.length; i++) {
            if(t.players[i].hole < 18) {
                completed = false;
                i = t.players.length;
            }
        }
        if(completed) {
            response.setHeader('Access-Control-Allow-Origin', '*');
            return response.status(405).send('The tournament is completed. You are not allowed to modify this resource.');
        }
    let foundPlayer = false;
    let p = undefined;
    let pDex = 0;
    for(let i = 0; i < t.players.length; i++) {
        if(t.players[i].firstinitial == player.firstinitial && t.players[i].lastname == player.lastname) {
            foundPlayer = true;
            p = t.players[i];
            pDex = i;
            break;
        }
    }
    if(!foundPlayer) {
        response.setHeader('Access-Control-Allow-Origin', '*');
        return response.status(404).send('The specified player was not found.');
    }
    // Remove player and rewrite persistentStore
    t.players.splice(pDex, 1);
    rawTournaments = JSON.stringify(tournaments);
    fs.writeFileSync('persistentStore.json', rawTournaments);
    response.setHeader('Access-Control-Allow-Origin', '*');
    return response.status(200).send(t);
})

// GET All Tournaments
app.get('/tournaments', (request, response) => {
    // This method will automatically search for query strings lb and ub
    // to represent lower bound and upper bound for years to filter tournaments.
    let lb = request.query.lb;
    let ub = request.query.ub;
    tournObject = [];
    for(let i = 0; i < tournaments['tournaments'].length; i++) {
        if(lb == undefined || ub == undefined || isNaN(lb || isNaN(ub))) {
            tournObject.push(
                {
                    name: tournaments['tournaments'][i].name,
                    year: tournaments['tournaments'][i].year,
                    award: tournaments['tournaments'][i].award,
                    yardage: tournaments['tournaments'][i].yardage,
                    par: tournaments['tournaments'][i].par
                }
            );
        }
        else if(!isNaN(lb) && !isNaN(ub)) {
            if(tournaments['tournaments'][i].year >= lb && tournaments['tournaments'][i].year <= ub) {
                tournObject.push(
                    {
                        name: tournaments['tournaments'][i].name,
                        year: tournaments['tournaments'][i].year,
                        award: tournaments['tournaments'][i].award,
                        yardage: tournaments['tournaments'][i].yardage,
                        par: tournaments['tournaments'][i].par
                    }
                );
            }
        }
    }
    response.setHeader('Content-Type', 'text/json');
    response.setHeader('Access-Control-Allow-Origin', '*');
    return response.status(200).send(tournObject);
})

// GET Players in Tournament (Getting by tournament name)
app.get('/players/:id', (request, response) => {
    const tournamentName = request.params.id;
    let foundTournament = false;
    let t = undefined;
    for(let i = 0; i < tournaments['tournaments'].length; i++) {
        if(tournaments['tournaments'][i].name == tournamentName) {
            t = tournaments['tournaments'][i];
            foundTournament = true;
            break;
        }
    }
    if(!foundTournament) {
        response.setHeader('Access-Control-Allow-Origin', '*');
        return response.status(404).send('The specified tournament was not found.');
    }
    response.setHeader('Access-Control-Allow-Origin', '*');
    return response.send(t.players);
})

// POST new player
app.post('/players', (request, response) => {
    const { error } = playerUtils.validatePlayer(request.body);
    if(error) {
        response.setHeader('Access-Control-Allow-Origin', '*');
        return response.status(400).send('The player must have a non-empty last name and a first initial no longer than 1 character.');
    }
    const player = {
        lastname: request.body.lastname,
        firstinitial: request.body.firstinitial,
        score: 0,
        hole: 0
    }
    for(let i = 0; i < players['players'].length; i++) {
        if(players['players'][i].lastname == player.lastname && players['players'][i].firstinitial == player.firstinitial) {
            response.setHeader('Access-Control-Allow-Origin', '*');
            return response.status(409).send('A Player of that name already exists.');
        }
    }
    players['players'].push(player);
    rawPlayers = JSON.stringify(players);
    fs.writeFileSync('persistentStorePlayers.json', rawPlayers);
    response.setHeader('Access-Control-Allow-Origin', '*');
    return response.status(201).send(player);
})

// PATCH player's score if player is in tournament (hole 0 can represent player not in tournament)
app.patch('/tournaments/player/:id', (request, response) => {
    //name in this case can represent the concatenation of first initial and lastname of player.
    const { error } = playerUtils.validatePlayer(request.body);
    if(error) {
        response.setHeader('Access-Control-Allow-Origin', '*');
        return response.status(400).send('The player must have a non-empty last name and a first initial no longer than 1 character.');
    }
    const player = {
        lastname: request.body.lastname,
        firstinitial: request.body.firstinitial,
        score: request.body.score, // score will be added by the amount here
        hole: request.body.hole
    }
    const tournamentName = request.params.id;
    let foundTournament = false;
    let t = undefined;
    for(let i = 0; i < tournaments['tournaments'].length; i++) {
        if(tournaments['tournaments'][i].name == tournamentName) {
            t = tournaments['tournaments'][i];
            foundTournament = true;
            break;
        }
    }
    if(!foundTournament) {
        response.setHeader('Access-Control-Allow-Origin', '*');
        return response.status(404).send('The specified tournament was not found.');
    }
    let completed = true;
    for(let i = 0; i < t.players.length; i++) {
        if(t.players[i].hole < 18) {
            completed = false;
            i = t.players.length;
        }
    }
    if(completed) {
        response.setHeader('Access-Control-Allow-Origin', '*');
        return response.status(405).send('The tournament is completed. You are not allowed to modify this resource.');
    }
    let p = undefined;
    let foundPlayer = false;
    for(let i = 0; i < t.players.length; i++) {
        if(t.players[i].firstinitial == player.firstinitial && t.players[i].lastname == player.lastname) {
            p = t.players[i];
            foundPlayer = true;
        }
    }
    if(!foundPlayer) {
        response.setHeader('Access-Control-Allow-Origin', '*');
        return response.status(404).send('The specified player was not found.');
    }
    if(p.hole < 18) {
        p.score += player.score;
        p.hole++;
    }
    else {
        response.setHeader('Access-Control-Allow-Origin', '*');
        return response.status(405).send('The player has finished this tournament. You are not allowed to modify this resource.');
    }
    rawTournaments = JSON.stringify(tournaments);
    fs.writeFileSync('persistentStore.json', rawTournaments);
    response.setHeader('Access-Control-Allow-Origin', '*');
    return response.status(200).send(t);
})

// POST Tournament
app.post('/tournaments', (request, response) => {
    // For some reason, validating the player still isn't working.
    // This will be addressed later.
    const { error } = tournUtils.validateTournament(request.body);
    if(error) {
        response.setHeader('Access-Control-Allow-Origin', '*');
        return response.status(400).send('The name must not be empty and numbers and strings should be used appropriately.');
    }
    const tourn = {
        name: request.body.name,
        year: request.body.year,
        award: request.body.award,
        yardage: request.body.yardage,
        par: request.body.par,
        players: request.body.players
    }
    if(tourn.players.length != 0) {
        for(let i = 0; i < tourn.players.length; i++) {
            const { playerError } = playerUtils.validatePlayer(tourn.players[i]);
            if(playerError) {
                response.setHeader('Access-Control-Allow-Origin', '*');
                return response.status(400).send('The player must have a non-empty last name and a first initial no longer than 1 character.');
            }
        }
    } 

    // Also needs to check if the tournament already exists. Would also be a 409.
    for(let i = 0; i < tournaments['tournaments'].length; i++) {
        if(tournaments['tournaments'][i].name == tourn.name) {
            response.setHeader('Access-Control-Allow-Origin', '*');
            return response.status(409).send('A Tournament of that name already exists.');
        }
    }
    for(let i = 0; i < tournaments['tournaments'].length; i++) {
        for(let j = 0; j < tournaments['tournaments'][i].players.length; j++) {
            for(let k = 0; k < tourn.players.length; k++) {
                if(tournaments['tournaments'][i].players[j].lastname == tourn.players[k].lastname && tournaments['tournaments'][i].players[j].firstinitial == tourn.players[k].firstinitial) {
                    // Check if examined tournament is complete
                    let complete = true;
                    for(let m = 0; m < tournaments['tournaments'][i].players.length; m++) {
                        if(tournaments['tournaments'][i].players[m].hole < 18) {
                            complete = false;
                            m = tournaments['tournaments'][i].players.length
                        }
                    }
                    if(!complete) {
                        response.setHeader('Access-Control-Allow-Origin', '*');
                        return response.status(409).send('A Player of that name already exists.');
                    }
                }
            }
        }
    }
    tournaments['tournaments'].push(tourn);
    rawTournaments = JSON.stringify(tournaments);
    fs.writeFileSync('persistentStore.json', rawTournaments);
    response.setHeader('Access-Control-Allow-Origin', '*');
    return response.status(201).send(tourn);
})


const port = process.env.PORT || 8000;
app.listen(port, () => console.log(`Listening on port ${port}`))